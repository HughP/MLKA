The files in this directory were produced by using the Live Trace feature of
Adobe Illustrator with the default settings. Separate files for individual
letters were produced by creating a square artboard and setting the letter
height to 80% of the artboard height. No smoothing or path transformations
have been performed.