
GYLMWP KEYBOARD LAYOUT

COLEMAK IMPROVEMENT (ZXCV FIXED) LAYOUT FOR ENGLISH TEXT


DESCRIPTION

This is keyboard layout for use with the Portable Keyboard Layout (PKL). 

This layout is one of the Colemak improvements, created by adjusting typing model parameters to improve all effort components (base, penalty, stroke).

For more information about this layout and how it was created see

http://mkweb.bcgsc.ca/carpalx/?improving_colemak


INSTALLATION

To make use of this layout with PKL:

1. download PKL at http://pkl.sourceforge.net/
2. install PKL
3. place this layout directory in pkl/layouts
4. add this layout to pkl.ini file by appending it to the 'layout' variable, such as

   layout = ...,gylmwp:carpalx - Colemak improvement (zxcv fixed)

To select the layout, run PKL, right click the PKL icon in the system tray and select 

   layouts > carpalx - Colemak improvement (zxcv fixed)




Martin Krzywinski
mkweb.bcgsc.ca/carpalx
