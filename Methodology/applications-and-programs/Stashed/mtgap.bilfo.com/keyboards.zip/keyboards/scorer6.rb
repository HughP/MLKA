require "allthetrigraphs"

@klausler = {
	'k' => [0,0],
	',' => [0,1],
	'u' => [0,2],
	'y' => [0,3],
	'p' => [0,4],
	'w' => [0,5],
	'l' => [0,6],
	'm' => [0,7],
	'f' => [0,8],
	'c' => [0,9],
	'o' => [1,0],
	'a' => [1,1],
	'e' => [1,2],
	'i' => [1,3],
	'd' => [1,4],
	'r' => [1,5],
	'n' => [1,6],
	't' => [1,7],
	'h' => [1,8],
	's' => [1,9],
	'q' => [2,0],
	'.' => [2,1],
	'\'' => [2,2],
	';' => [2,3],
	'z' => [2,4],
	'x' => [2,5],
	'v' => [2,6],
	'g' => [2,7],
	'b' => [2,8],
	'j' => [2,9]
}

@dvorak = {
	'\'' => [0,0],
	',' => [0,1],
	'.' => [0,2],
	'p' => [0,3],
	'y' => [0,4],
	'f' => [0,5],
	'g' => [0,6],
	'c' => [0,7],
	'r' => [0,8],
	'l' => [0,9],
	'a' => [1,0],
	'o' => [1,1],
	'e' => [1,2],
	'u' => [1,3],
	'i' => [1,4],
	'd' => [1,5],
	'h' => [1,6],
	't' => [1,7],
	'n' => [1,8],
	's' => [1,9],
	';' => [2,0],
	'q' => [2,1],
	'j' => [2,2],
	'k' => [2,3],
	'x' => [2,4],
	'b' => [2,5],
	'm' => [2,6],
	'w' => [2,7],
	'v' => [2,8],
	'z' => [2,9]
}

@colemak = {
	'q' => [0,0],
	'w' => [0,1],
	'f' => [0,2],
	'p' => [0,3],
	'g' => [0,4],
	'j' => [0,5],
	'l' => [0,6],
	'u' => [0,7],
	'y' => [0,8],
	';' => [0,9],
	'a' => [1,0],
	'r' => [1,1],
	's' => [1,2],
	't' => [1,3],
	'd' => [1,4],
	'h' => [1,5],
	'n' => [1,6],
	'e' => [1,7],
	'i' => [1,8],
	'o' => [1,9],
	'z' => [2,0],
	'x' => [2,1],
	'c' => [2,2],
	'v' => [2,3],
	'b' => [2,4],
	'k' => [2,5],
	'm' => [2,6],
	',' => [2,7],
	'.' => [2,8],
	'\'' => [2,9]
}
#note: m and w might be switched
@capewell = {
	'.' => [0,0],
	'y' => [0,1],
	'm' => [0,2],
	'd' => [0,3],
	'f' => [0,4],
	'j' => [0,5],
	'p' => [0,6],
	'l' => [0,7],
	'u' => [0,8],
	'q' => [0,9],
	'a' => [1,0],
	'e' => [1,1],
	'r' => [1,2],
	's' => [1,3],
	'g' => [1,4],
	'b' => [1,5],
	't' => [1,6],
	'n' => [1,7],
	'i' => [1,8],
	'o' => [1,9],
	'x' => [2,0],
	'z' => [2,1],
	'c' => [2,2],
	'v' => [2,3],
	';' => [2,4],
	'k' => [2,5],
	'w' => [2,6],
	'h' => [2,7],
	',' => [2,8],
	'\'' => [2,9]
}

@arensito = {
	'q' => [0,0],
	'l' => [0,1],
	'.' => [0,2],
	'p' => [0,3],
	'\'' => [0,4],
	';' => [0,5],
	'f' => [0,6],
	'u' => [0,7],
	'd' => [0,8],
	'k' => [0,9],
	'a' => [1,0],
	'r' => [1,1],
	'e' => [1,2],
	'n' => [1,3],
	'b' => [1,4],
	'g' => [1,5],
	's' => [1,6],
	'i' => [1,7],
	't' => [1,8],
	'o' => [1,9],
	'z' => [2,0],
	'w' => [2,1],
	',' => [2,2],
	'h' => [2,3],
	'j' => [2,4],
	'v' => [2,5],
	'c' => [2,6],
	'y' => [2,7],
	'm' => [2,8],
	'x' => [2,9]
}

@qwerty = {
	'q' => [0,0],
	'w' => [0,1],
	'e' => [0,2],
	'r' => [0,3],
	't' => [0,4],
	'y' => [0,5],
	'u' => [0,6],
	'i' => [0,7],
	'o' => [0,8],
	'p' => [0,9],
	'a' => [1,0],
	's' => [1,1],
	'd' => [1,2],
	'f' => [1,3],
	'g' => [1,4],
	'h' => [1,5],
	'j' => [1,6],
	'k' => [1,7],
	'l' => [1,8],
	';' => [1,9],
	'z' => [2,0],
	'x' => [2,1],
	'c' => [2,2],
	'v' => [2,3],
	'b' => [2,4],
	'n' => [2,5],
	'm' => [2,6],
	',' => [2,7],
	'.' => [2,8],
	'\'' => [2,9]
}

@nisa = {
	'q' => [0,0],
	'w' => [0,1],
	'u' => [0,2],
	'p' => [0,3],
	'g' => [0,4],
	'k' => [0,5],
	'l' => [0,6],
	'y' => [0,7],
	'c' => [0,8],
	',' => [0,9],
	'o' => [1,0],
	'r' => [1,1],
	'e' => [1,2],
	't' => [1,3],
	'd' => [1,4],
	'h' => [1,5],
	'n' => [1,6],
	'i' => [1,7],
	's' => [1,8],
	'a' => [1,9],
	'z' => [2,0],
	'x' => [2,1],
	'\'' => [2,2],
	'v' => [2,3],
	'j' => [2,4],
	'b' => [2,5],
	'm' => [2,6],
	'.' => [2,7],
	'f' => [2,8],
	';' => [2,9]
}

@tero = {
	'q' => [0,0],
	'h' => [0,1],
	'y' => [0,2],
	'f' => [0,3],
	'k' => [0,4],
	'b' => [0,5],
	'w' => [0,6],
	'u' => [0,7],
	'l' => [0,8],
	'\'' => [0,9],
	'a' => [1,0],
	'n' => [1,1],
	'i' => [1,2],
	's' => [1,3],
	'd' => [1,4],
	'g' => [1,5],
	't' => [1,6],
	'e' => [1,7],
	'r' => [1,8],
	'o' => [1,9],
	'z' => [2,0],
	'v' => [2,1],
	'x' => [2,2],
	'c' => [2,3],
	'j' => [2,4],
	'p' => [2,5],
	'm' => [2,6],
	',' => [2,7],
	'.' => [2,8],
	';' => [2,9]
}

@oist = {
	'.' => [0,0],
	'y' => [0,1],
	'c' => [0,2],
	'g' => [0,3],
	'b' => [0,4],
	'k' => [0,5],
	'l' => [0,6],
	'u' => [0,7],
	'w' => [0,8],
	',' => [0,9],
	'o' => [1,0],
	'i' => [1,1],
	's' => [1,2],
	't' => [1,3],
	'd' => [1,4],
	'h' => [1,5],
	'n' => [1,6],
	'e' => [1,7],
	'r' => [1,8],
	'a' => [1,9],
	'z' => [2,0],
	'x' => [2,1],
	'v' => [2,2],
	'p' => [2,3],
	'q' => [2,4],
	'f' => [2,5],
	'm' => [2,6],
	'\'' => [2,7],
	'j' => [2,8],
	';' => [2,9]
}

@sier = {
	'c' => [0,0],
	'y' => [0,1],
	'u' => [0,2],
	'l' => [0,3],
	'w' => [0,4],
	'b' => [0,5],
	'p' => [0,6],
	'.' => [0,7],
	'f' => [0,8],
	'\'' => [0,9],
	's' => [1,0],
	'i' => [1,1],
	'e' => [1,2],
	'r' => [1,3],
	'h' => [1,4],
	'd' => [1,5],
	't' => [1,6],
	'a' => [1,7],
	'n' => [1,8],
	'o' => [1,9],
	'j' => [2,0],
	'z' => [2,1],
	'x' => [2,2],
	'v' => [2,3],
	'q' => [2,4],
	'g' => [2,5],
	'm' => [2,6],
	',' => [2,7],
	'k' => [2,8],
	';' => [2,9]
}

@evolved = {
	'q' => [0,0],
	'w' => [0,1],
	'h' => [0,2],
	'm' => [0,3],
	';' => [0,4],
	'k' => [0,5],
	'p' => [0,6],
	'u' => [0,7],
	'f' => [0,8],
	'\'' => [0,9],
	'i' => [1,0],
	'r' => [1,1],
	'n' => [1,2],
	's' => [1,3],
	'l' => [1,4],
	'd' => [1,5],
	't' => [1,6],
	'e' => [1,7],
	'a' => [1,8],
	'o' => [1,9],
	'x' => [2,0],
	'z' => [2,1],
	'v' => [2,2],
	'c' => [2,3],
	'j' => [2,4],
	'b' => [2,5],
	'g' => [2,6],
	'y' => [2,7],
	',' => [2,8],
	'.' => [2,9]
}

@thevolved = {
	'k' => [0,0],
	'y' => [0,1],
	'u' => [0,2],
	'w' => [0,3],
	'b' => [0,4],
	'j' => [0,5],
	'v' => [0,6],
	'l' => [0,7],
	'f' => [0,8],
	'\'' => [0,9],
	'r' => [1,0],
	'e' => [1,1],
	'i' => [1,2],
	'n' => [1,3],
	'c' => [1,4],
	's' => [1,5],
	'h' => [1,6],
	't' => [1,7],
	'a' => [1,8],
	'o' => [1,9],
	';' => [2,0],
	'.' => [2,1],
	'x' => [2,2],
	'p' => [2,3],
	'z' => [2,4],
	'j' => [2,5],
	'm' => [2,6],
	'd' => [2,7],
	'q' => [2,8],
	',	' => [2,9]
}

@tsevolved = {
	'k' => [0,0],
	'y' => [0,1],
	'u' => [0,2],
	'w' => [0,3],
	'b' => [0,4],
	'j' => [0,5],
	'v' => [0,6],
	'l' => [0,7],
	'f' => [0,8],
	'\'' => [0,9],
	'r' => [1,0],
	'e' => [1,1],
	'i' => [1,2],
	'n' => [1,3],
	'c' => [1,4],
	'h' => [1,5],
	's' => [1,6],
	't' => [1,7],
	'a' => [1,8],
	'o' => [1,9],
	';' => [2,0],
	'.' => [2,1],
	'x' => [2,2],
	'p' => [2,3],
	'z' => [2,4],
	'j' => [2,5],
	'm' => [2,6],
	'd' => [2,7],
	'q' => [2,8],
	',	' => [2,9]
}

@finger = {
	'x' => [0,0],
	'w' => [0,1],
	'd' => [0,2],
	'f' => [0,3],
	'b' => [0,4],
	'k' => [0,5],
	'h' => [0,6],
	'u' => [0,7],
	'\'' => [0,8],
	'.' => [0,9],
	'o' => [1,0],
	'r' => [1,1],
	't' => [1,2],
	's' => [1,3],
	'c' => [1,4],
	'l' => [1,5],
	'n' => [1,6],
	'i' => [1,7],
	'e' => [1,8],
	'a' => [1,9],
	'z' => [2,0],
	';' => [2,1],
	'g' => [2,2],
	'v' => [2,3],
	'q' => [2,4],
	'p' => [2,5],
	'm' => [2,6],
	'y' => [2,7],
	'j' => [2,8],
	',' => [2,9]
}
# e: ' j            t: d g
# a: . ,            o: x z
# i: u y            n: l m p h k
# s: f b q c v      r: w ;

@evolvedqwerty = {
	'q' => [0,0],
	'w' => [0,1],
	'd' => [0,2],
	'f' => [0,3],
	'b' => [0,4],
	'j' => [0,5],
	'y' => [0,6],
	'u' => [0,7],
	'l' => [0,8],
	'p' => [0,9],
	'a' => [1,0],
	's' => [1,1],
	'r' => [1,2],
	't' => [1,3],
	'g' => [1,4],
	'h' => [1,5],
	'n' => [1,6],
	'e' => [1,7],
	'o' => [1,8],
	'i' => [1,9],
	'z' => [2,0],
	'x' => [2,1],
	'c' => [2,2],
	'v' => [2,3],
	';' => [2,4],
	'k' => [2,5],
	'm' => [2,6],
	',' => [2,7],
	'.' => [2,8],
	'\'' => [2,9]
}


class Scorer
	
	attr_accessor :keyboard
	
	def initialize
		@file = Trigraphs.new
		@trigraphs = @file.trigraphs
	  @is_ergo = 0
		if @is_ergo == 1
  		@key_score = {
  			[0,0] => 56,
  			[0,1] => 46,
  			[0,2] => 38,
  			[0,3] => 38,
  			[0,4] => 68,
  			[0,5] => 68,
  			[0,6] => 38,
  			[0,7] => 38,
  			[0,8] => 46,
  			[0,9] => 56,
  			[1,0] => 0,
  			[1,1] => -8,
  			[1,2] => -10,
  			[1,3] => -10,
  			[1,4] => 40,
  			[1,5] => 40,
  			[1,6] => -10,
  			[1,7] => -10,
  			[1,8] => -8,
  			[1,9] => 0,
  			[2,0] => 73,
  			[2,1] => 59,
  			[2,2] => 49,
  			[2,3] => 44,
  			[2,4] => 102,
  			[2,5] => 102,
  			[2,6] => 44,
  			[2,7] => 49,
  			[2,8] => 59,
  			[2,9] => 73
  		}
	  else
  		@key_score = {
  			[0,0] => 66,
  			[0,1] => 35,
  			[0,2] => 29,
  			[0,3] => 33,
  			[0,4] => 60,
  			[0,5] => 91,
  			[0,6] => 33,
  			[0,7] => 29,
  			[0,8] => 35,
  			[0,9] => 66,
  			[1,0] => 0,
  			[1,1] => -8,
  			[1,2] => -10,
  			[1,3] => -10,
  			[1,4] => 40,
  			[1,5] => 40,
  			[1,6] => -10,
  			[1,7] => -10,
  			[1,8] => -8,
  			[1,9] => 0,
  			[2,0] => 96,
  			[2,1] => 72,
  			[2,2] => 60,
  			[2,3] => 54,
  			[2,4] => 109,
  			[2,5] => 54,
  			[2,6] => 48,
  			[2,7] => 60,
  			[2,8] => 72,
  			[2,9] => 96
  		}		  
		end

	end


	def score_str(s, value)
		if @is_ergo == 0
  		roll = 10.0
  		samefinger = 65.0
  		samehand = 1.0
  		handwarp = 0.0
  		jumphome = 50.0
  		jumphomeindex = 20.0
  		rowchange = 10.0
  		tocenter = 10.0
		else
  		roll = 10.0
  		samefinger = 75.0
  		samehand = 1.0
  		handwarp = 0.0
  		jumphome = 55.0
  		jumphomeindex = 20.0
  		rowchange = 10.0
  		tocenter = 10.0
		end
		
		chars = 0
		score = 0.0
		effort = 0.0
		hand_count = 0.0
		finger_count = 0
		fingercountx = 0.0
		handcountx = 0.0
		indexcountx = 0.0
		handwarpcountx = 0.0
		jumphomecountx = 0.0
		rowchangecountx = 0.0
		tocentercountx = 0.0
		inrollcountx = 0.0
		outrollcountx = 0.0
		index_count = 0
		lpinky = 0.0
		lring = 0.0
		lmiddle = 0.0
		lindex = 0.0
		rindex = 0.0
		rmiddle = 0.0
		rring = 0.0
		rpinky = 0.0
		old_loc = nil
		real_old_loc = nil
		s.each_byte { |b|
			key_loc = @keyboard.keyboard[b.chr.downcase] # there can only be 1 of each letter
			if key_loc

				chars += value
				score += @key_score[key_loc]
				effort += @key_score[key_loc]*value
				
				if old_loc
					
					lefthand = old_loc[1] <= 4 and key_loc[1] <= 4
					righthand = old_loc[1] > 4 and key_loc[1] > 4
					lefthome = old_loc[1] < 4 and key_loc[1] < 4
					righthome = old_loc[1] > 5 and key_loc[1] > 5
					same_index = (key_loc[1] == 3 and old_loc[1] == 4) or (key_loc[1] == 4 and old_loc[1] == 3) or (key_loc[1] == 5 and old_loc[1] == 6) or (key_loc[1] == 6 and old_loc[1] == 5)
					same_finger = (key_loc[1] == old_loc[1])
					centerbefore = (old_loc[1] == 4 and key_loc[1] < 4) or (old_loc[1] == 5 and key_loc[1] > 5)
					centerafter = (key_loc[1] == 4 and old_loc[1] < 4) or (key_loc[1] == 5 and old_loc[1] > 5)
					
					inroll = ((lefthome and (key_loc[1]==old_loc[1]+1)) or (righthome and (key_loc[1]==old_loc[1]-1))) and (key_loc[0] == old_loc[0])
					outroll = ((lefthome and (key_loc[1]==old_loc[1]-1)) or (righthome and (key_loc[1]==old_loc[1]+1))) and (key_loc[0] == old_loc[0])
					
					if inroll
#						puts "inroll: #{old_loc} #{key_loc}"
						score -= roll
						inrollcountx += value
					end

					if outroll
						score -= roll/2
						outrollcountx += value
					end

					if real_old_loc			# penalties reduced by 66%

						# check for same hand
						lefthand = real_old_loc[1] <= 4 and key_loc[1] <= 4
						righthand = real_old_loc[1] > 4 and key_loc[1] > 4
						lefthome = real_old_loc[1] < 4 and key_loc[1] < 4
						righthome = real_old_loc[1] > 5 and key_loc[1] > 5
						same_index = (key_loc[1] == 3 and real_old_loc[1] == 4) or (key_loc[1] == 4 and real_old_loc[1] == 3) or (key_loc[1] == 5 and real_old_loc[1] == 6) or (key_loc[1] == 6 and real_old_loc[1] == 5)
						same_finger = (key_loc[1] == old_loc[1])
						centerbefore = (real_old_loc[1] == 4 and key_loc[1] < 4) or (real_old_loc[1] == 5 and key_loc[1] > 5)
						centerafter = (key_loc[1] == 4 and real_old_loc[1] < 4) or (key_loc[1] == 5 and real_old_loc[1] > 5)

						if ((real_old_loc[1] <= 4 and old_loc[1] <= 4 and key_loc[1] <= 4) or (real_old_loc[1] > 4 and old_loc[1] > 4 and key_loc[1] > 4)) and ((key_loc[1] > old_loc[1] and old_loc[1] < real_old_loc[1]) or (key_loc[1] < old_loc[1] and old_loc[1] > real_old_loc[1]))
#							puts "same hand: #{real_old_loc} #{old_loc} #{key_loc}"
							score += samehand
							handcountx += value
						else
							hand_count = 0
						end

						if same_finger
							if key_loc[0] == real_old_loc[0]
							else
								score += samefinger/3
							end
						end

						if old_loc[1] == 3 and key_loc[1] == 4
							score += samefinger/3
						elsif old_loc[1] == 4 and key_loc[1] == 3
							score += samefinger/3
						elsif old_loc[1] == 5 and key_loc[1] == 6
							score += samefinger/3
						elsif old_loc[1] == 6 and key_loc[1] == 5
							score += samefinger/3
						end
						
						if old_loc == " "

							if (old_loc[1] <= 4 and key_loc[1] <= 4) or (old_loc[1] > 4 and key_loc[1] > 4)
								if ((key_loc[0] == 0 and old_loc[0] == 2) or (key_loc[0] == 2 and old_loc[0] == 0))
									score += jumphome/3
									if  ((key_loc[1] == 3 or key_loc[1] == 4 or key_loc[1] == 5 or key_loc[1] == 6) and key_loc[0] == 2) or ((old_loc[1] == 3 or old_loc[1] == 4 or old_loc[1] == 5 or old_loc[1] == 6) and old_loc[1] == 2)
										score -= (jumphome-jumphomeindex)/3
									end
		#							puts "jumphome: #{old_loc} #{key_loc}"
								elsif (key_loc[0] == old_loc[0] + 1) or (key_loc[0] == old_loc[0] - 1)
								end
							end

							if centerbefore
								score += tocenter/3
		#						puts "move to center: #{old_loc} #{key_loc}"
							end

							if centerafter
								score += tocenter/3
		#						puts "move to center: #{old_loc} #{key_loc}"
							end



						end # old loc = space


					end #real old loc

					#check for same finger
					if same_finger
						if key_loc[0] == old_loc[0]
						else
#							puts "same finger: #{old_loc} #{key_loc}"
							score += samefinger
							fingercountx += value
						end
					end

					if old_loc[1] == 3 and key_loc[1] == 4
						score += samefinger
						fingercountx += value
					elsif old_loc[1] == 4 and key_loc[1] == 3
						score += samefinger
						fingercountx += value
					elsif old_loc[1] == 5 and key_loc[1] == 6
						score += samefinger
						fingercountx += value
					elsif old_loc[1] == 6 and key_loc[1] == 5
						score += samefinger
						fingercountx += value
					end

          if @is_ergo == 0
  					# moving up and out within 1 hand					
  					if lefthand
  						if key_loc[0] > old_loc[0]
  							if (old_loc[1] == 0 and key_loc[1] == 1) or (old_loc[1] == 3 and key_loc[1] == 2)
  								score += handwarp
  								handwarpcountx += value
  #								puts "handwarp: #{old_loc} #{key_loc}"
  							end
  						elsif key_loc[0] < old_loc[0]
  							if (old_loc[1] == 1 and key_loc[1] == 0) or (old_loc[1] == 2 and key_loc[1] == 3)
  								score += handwarp
  								handwarpcountx += value
  #								puts "handwarp: #{old_loc} #{key_loc}"
  							end
  						end
  					end

  					if righthand
  						if key_loc[0] > old_loc[0]
  							if (old_loc[1] == 9 and key_loc[1] == 8) or (old_loc[1] == 6 and key_loc[1] == 7)
  								score += handwarp
  								handwarpcountx += value
  #								puts "handwarp: #{old_loc} #{key_loc}"
  							end
  						elsif key_loc[0] < old_loc[0]
  							if (old_loc[1] == 8 and key_loc[1] == 9) or (old_loc[1] == 7 and key_loc[1] == 6)
  								score += handwarp
  								handwarpcountx += value
  #								puts "handwarp: #{old_loc} #{key_loc}"
  							end
  						end
  					end
					end

					#check for jump home
					if (old_loc[1] <= 4 and key_loc[1] <= 4) or (old_loc[1] > 4 and key_loc[1] > 4)

						if ((key_loc[0] == 0 and old_loc[0] == 2) or (key_loc[0] == 2 and old_loc[0] == 0))
							jumphomecountx += value
							score += jumphome
							if  ((key_loc[1] == 3 or key_loc[1] == 4 or key_loc[1] == 5 or key_loc[1] == 6) and key_loc[0] == 2) or ((old_loc[1] == 3 or old_loc[1] == 4 or old_loc[1] == 5 or old_loc[1] == 6) and old_loc[1] == 2)
								score -= (jumphome-jumphomeindex)
								jumphomecountx -= value
							end
#							puts "jumphome: #{old_loc} #{key_loc}"
						elsif (key_loc[0] == old_loc[0] + 1) or (key_loc[0] == old_loc[0] - 1)
							score += rowchange
							rowchangecountx += value
						end
					end

					#check for finger switching					
					if centerbefore
						score += tocenter
						tocentercountx += value
#						puts "move to center: #{old_loc} #{key_loc}"
					end

					if centerafter
						score += tocenter
						tocentercountx += value
#						puts "move to center: #{old_loc} #{key_loc}"
					end

				  
				end
				
			end #key_loc
			real_old_loc = old_loc
			old_loc = key_loc

		}
		
		score = score * value
		
		{ 'chars' => chars,
			'score' => score,
			'effort' => effort,
			'handcount' => handcountx,
			'fingercount' => fingercountx,
			'indexcount' => indexcountx,
			'handwarpcount' => handwarpcountx,
			'jumphomecount' => jumphomecountx,
			'rowchangecount' => rowchangecountx,
			'tocentercount' => tocentercountx,
			'inrollcount' => inrollcountx,
			'outrollcount' => outrollcountx,
			'lpinky' => lpinky,
			'lring' => lring,
			'lmiddle' => lmiddle,
			'lindex' => lindex,
			'rindex' => rindex,
			'rmiddle' => rmiddle,
			'rring' => rring,
			'rpinky' => rpinky			
		}
	end


	def score_file(keyboard)
		@trigraphs = @file.trigraphs
		@keyboard = keyboard
		chars = 0
		score = 0
		effort = 0
		handcountx = 0
		fingercountx = 0
		indexcountx = 0
		handwarpcountx = 0
		jumphomecountx = 0
		rowchangecountx = 0
		tocentercountx = 0
		inrollcountx = 0
		outrollcountx = 0
		lpinky = 0.0
		lring = 0.0
		lmiddle = 0.0
		lindex = 0.0
		rindex = 0.0
		rmiddle = 0.0
		rring = 0.0
		rpinky = 0.0
		@trigraphs.each { |line, value|
			result = score_str(line, value)
			chars += result['chars']
			score += result['score']
			effort += result['effort']
			handcountx += result['handcount']
			fingercountx += result['fingercount']
			indexcountx += result['indexcount']
			handwarpcountx += result['handwarpcount']
			jumphomecountx += result['jumphomecount']
			rowchangecountx += result['rowchangecount']
			tocentercountx += result['tocentercount']
			inrollcountx += result['inrollcount']
			outrollcountx += result['outrollcount']
			lpinky += result['lpinky']
			lring += result['lring']
			lmiddle += result['lmiddle']
			lindex += result['lindex']
			rindex += result['rindex']
			rmiddle += result['rmiddle']
			rring += result['rring']
			rpinky += result['rpinky']
		}
		score = score * 1.0
		score = score / chars

		# checking for shortcuts
		# note: switching C and Z on Colemak increases score by 0.4

		shortcutsgood = 0
		if shortcutsgood == 1
		  shortcut = 0.3
			if @keyboard.keyboard["z"] == [2,0] or @keyboard.keyboard["x"] == [2,0] or @keyboard.keyboard["c"] == [2,0] or @keyboard.keyboard["v"] == [2,0]
				score -= shortcut
			end
			if @keyboard.keyboard["z"] == [2,1] or @keyboard.keyboard["x"] == [2,1] or @keyboard.keyboard["c"] == [2,1] or @keyboard.keyboard["v"] == [2,1]
				score -= shortcut
			end
			if @keyboard.keyboard["z"] == [2,2] or @keyboard.keyboard["x"] == [2,2] or @keyboard.keyboard["c"] == [2,2] or @keyboard.keyboard["v"] == [2,2]
				score -= shortcut
			end
			if @keyboard.keyboard["z"] == [2,3] or @keyboard.keyboard["x"] == [2,3] or @keyboard.keyboard["c"] == [2,3] or @keyboard.keyboard["v"] == [2,3]
				score -= shortcut
			end
			if @keyboard.keyboard["q"] == [0,0]
				score -= shortcut/2
			end
			if @keyboard.keyboard["h"] == [0,1] or @keyboard.keyboard["w"] == [0,1]
				score -= shortcut/4
			end
			if @keyboard.keyboard["h"] == [0,0] or @keyboard.keyboard["w"] == [0,0]
				score -= shortcut/4
			end
		end
		
		# make it same as qwerty
		qwertygood = 0
		if qwertygood == 1
			qwerty = [
				'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p',
				'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
				'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '\'',
			]
      @qwerty = {
      	'q' => [0,0],
      	'w' => [0,1],
      	'e' => [0,2],
      	'r' => [0,3],
      	't' => [0,4],
      	'y' => [0,5],
      	'u' => [0,6],
      	'i' => [0,7],
      	'o' => [0,8],
      	'p' => [0,9],
      	'a' => [1,0],
      	's' => [1,1],
      	'd' => [1,2],
      	'f' => [1,3],
      	'g' => [1,4],
      	'h' => [1,5],
      	'j' => [1,6],
      	'k' => [1,7],
      	'l' => [1,8],
      	';' => [1,9],
      	'z' => [2,0],
      	'x' => [2,1],
      	'c' => [2,2],
      	'v' => [2,3],
      	'b' => [2,4],
      	'n' => [2,5],
      	'm' => [2,6],
      	',' => [2,7],
      	'.' => [2,8],
      	'\'' => [2,9]
      }
			@qwerty.each { |key, value|
			  if @keyboard.keyboard["#{key}"] == @qwerty["#{key}"]
			    score -= 0.2
			  end
			  if @keyboard.keyboard["#{key}"][1] == @qwerty["#{key}"][1]
			    score -= 0.02
			  end
			  if (@keyboard.keyboard["#{key}"][1] <= 4 and @qwerty["#{key}"][1] <= 4) or (@keyboard.keyboard["#{key}"][1] > 4 and @qwerty["#{key}"][1] > 4)
			  else
			    score += 0.05
			  end
			}
		end
		

		{ 'score' => score,
			'effort' => effort,
			'handcount' => handcountx,
			'fingercount' => fingercountx,
			'indexcount' => indexcountx,
			'handwarpcount' => handwarpcountx,
			'jumphomecount' => jumphomecountx,
			'rowchangecount' => rowchangecountx,
			'tocentercount' => tocentercountx,
			'inrollcount' => inrollcountx,
			'outrollcount' => outrollcountx,
#			'lpinky' => lpinky,
#			'lring' => lring,
#			'lmiddle' => lmiddle,
#			'lindex' => lindex,
#			'rindex' => rindex,
#			'rmiddle' => rmiddle,
#			'rring' => rring,
#			'rpinky' => rpinky
		}
	end

end