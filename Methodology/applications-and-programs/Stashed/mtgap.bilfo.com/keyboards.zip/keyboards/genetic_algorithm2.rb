class Algorithm
  
  def run
    require "scorer6"
    require "keyboard1"


    @scorer = Scorer.new

    @colemak1 = {
    'q' => [0,0],
    'w' => [0,1],
    'f' => [0,2],
    'p' => [0,3],
    'g' => [0,4],
    'j' => [0,5],
    'l' => [0,6],
    'u' => [0,7],
    'y' => [0,8],
    ';' => [0,9],
    'a' => [1,0],
    'r' => [1,1],
    's' => [1,2],
    't' => [1,3],
    'd' => [1,4],
    'h' => [1,5],
    'n' => [1,6],
    'e' => [1,7],
    'i' => [1,8],
    'o' => [1,9],
    'z' => [2,0],
    'x' => [2,1],
    'c' => [2,2],
    'v' => [2,3],
    'b' => [2,4],
    'k' => [2,5],
    'm' => [2,6],
    ',' => [2,7],
    '.' => [2,8],
    '\'' => [2,9]
    }

    @klausler1 = {
    'k' => [0,0],
    ',' => [0,1],
    'u' => [0,2],
    'y' => [0,3],
    'p' => [0,4],
    'w' => [0,5],
    'l' => [0,6],
    'm' => [0,7],
    'f' => [0,8],
    'c' => [0,9],
    'o' => [1,0],
    'a' => [1,1],
    'e' => [1,2],
    'i' => [1,3],
    'd' => [1,4],
    'r' => [1,5],
    'n' => [1,6],
    't' => [1,7],
    'h' => [1,8],
    's' => [1,9],
    'q' => [2,0],
    '.' => [2,1],
    '\'' => [2,2],
    ';' => [2,3],
    'z' => [2,4],
    'x' => [2,5],
    'v' => [2,6],
    'g' => [2,7],
    'b' => [2,8],
    'j' => [2,9]
    }

    @capewell1 = {
    '.' => [0,0],
    'y' => [0,1],
    'w' => [0,2],
    'd' => [0,3],
    'f' => [0,4],
    'j' => [0,5],
    'p' => [0,6],
    'l' => [0,7],
    'u' => [0,8],
    'q' => [0,9],
    'a' => [1,0],
    'e' => [1,1],
    'r' => [1,2],
    's' => [1,3],
    'g' => [1,4],
    'b' => [1,5],
    't' => [1,6],
    'n' => [1,7],
    'i' => [1,8],
    'o' => [1,9],
    'x' => [2,0],
    'z' => [2,1],
    'c' => [2,2],
    'v' => [2,3],
    ';' => [2,4],
    'k' => [2,5],
    'm' => [2,6],
    'h' => [2,7],
    ',' => [2,8],
    '\'' => [2,9]
    }

    @arensito1 = {
    'q' => [0,0],
    'l' => [0,1],
    '.' => [0,2],
    'p' => [0,3],
    '\'' => [0,4],
    ';' => [0,5],
    'f' => [0,6],
    'u' => [0,7],
    'd' => [0,8],
    'k' => [0,9],
    'a' => [1,0],
    'r' => [1,1],
    'e' => [1,2],
    'n' => [1,3],
    'b' => [1,4],
    'g' => [1,5],
    's' => [1,6],
    'i' => [1,7],
    't' => [1,8],
    'o' => [1,9],
    'z' => [2,0],
    'w' => [2,1],
    ',' => [2,2],
    'h' => [2,3],
    'j' => [2,4],
    'v' => [2,5],
    'c' => [2,6],
    'y' => [2,7],
    'm' => [2,8],
    'x' => [2,9]
    }

    @nisa1 = {
    'q' => [0,0],
    'w' => [0,1],
    'u' => [0,2],
    'g' => [0,3],
    'p' => [0,4],
    'k' => [0,5],
    'l' => [0,6],
    'y' => [0,7],
    'c' => [0,8],
    ',' => [0,9],
    'o' => [1,0],
    'r' => [1,1],
    'e' => [1,2],
    't' => [1,3],
    'd' => [1,4],
    'h' => [1,5],
    'n' => [1,6],
    'i' => [1,7],
    's' => [1,8],
    'a' => [1,9],
    'z' => [2,0],
    'x' => [2,1],
    '\'' => [2,2],
    'v' => [2,3],
    'j' => [2,4],
    'b' => [2,5],
    'm' => [2,6],
    '.' => [2,7],
    'f' => [2,8],
    ';' => [2,9]
    }

    @tero1 = {
    'q' => [0,0],
    'h' => [0,1],
    'y' => [0,2],
    'f' => [0,3],
    'k' => [0,4],
    'b' => [0,5],
    'w' => [0,6],
    'u' => [0,7],
    'l' => [0,8],
    '\'' => [0,9],
    'a' => [1,0],
    'n' => [1,1],
    'i' => [1,2],
    's' => [1,3],
    'd' => [1,4],
    'g' => [1,5],
    't' => [1,6],
    'e' => [1,7],
    'r' => [1,8],
    'o' => [1,9],
    'z' => [2,0],
    'v' => [2,1],
    'x' => [2,2],
    'c' => [2,3],
    'j' => [2,4],
    'p' => [2,5],
    'm' => [2,6],
    ',' => [2,7],
    '.' => [2,8],
    ';' => [2,9]
    }

    @oist1 = {
    '.' => [0,0],
    'y' => [0,1],
    'c' => [0,2],
    'g' => [0,3],
    'b' => [0,4],
    'k' => [0,5],
    'l' => [0,6],
    'u' => [0,7],
    'w' => [0,8],
    ',' => [0,9],
    'o' => [1,0],
    'i' => [1,1],
    's' => [1,2],
    't' => [1,3],
    'd' => [1,4],
    'h' => [1,5],
    'n' => [1,6],
    'e' => [1,7],
    'r' => [1,8],
    'a' => [1,9],
    'z' => [2,0],
    'x' => [2,1],
    'v' => [2,2],
    'p' => [2,3],
    'q' => [2,4],
    'f' => [2,5],
    'm' => [2,6],
    '\'' => [2,7],
    'j' => [2,8],
    ';' => [2,9]
    }

    @evolved1 = {
    'q' => [0,0],
    'w' => [0,1],
    'r' => [0,2],
    'm' => [0,3],
    ';' => [0,4],
    'k' => [0,5],
    'p' => [0,6],
    'u' => [0,7],
    'f' => [0,8],
    '\'' => [0,9],
    'h' => [1,0],
    'i' => [1,1],
    'n' => [1,2],
    's' => [1,3],
    'l' => [1,4],
    'd' => [1,5],
    't' => [1,6],
    'e' => [1,7],
    'a' => [1,8],
    'o' => [1,9],
    'x' => [2,0],
    'z' => [2,1],
    'v' => [2,2],
    'c' => [2,3],
    'j' => [2,4],
    'b' => [2,5],
    'g' => [2,6],
    'y' => [2,7],
    ',' => [2,8],
    '.' => [2,9]
    }

    @colemak2 = {
    	'q' => [0,0],
    	'w' => [0,1],
    	'l' => [0,2],
    	'g' => [0,3],
    	'p' => [0,4],
    	'b' => [0,5],
    	'm' => [0,6],
    	'u' => [0,7],
    	'y' => [0,8],
    	',' => [0,9],
    	'o' => [1,0],
    	'r' => [1,1],
    	's' => [1,2],
    	't' => [1,3],
    	'd' => [1,4],
    	'h' => [1,5],
    	'n' => [1,6],
    	'e' => [1,7],
    	'i' => [1,8],
    	'a' => [1,9],
    	'z' => [2,0],
    	'x' => [2,1],
    	'v' => [2,2],
    	'c' => [2,3],
    	';' => [2,4],
    	',' => [2,5],
    	'f' => [2,6],
    	'k' => [2,7],
    	'j' => [2,8],
    	'\'' => [2,9]
    }

    @qcolemak = {
    	'q' => [0,0],
    	'w' => [0,1],
    	'f' => [0,2],
    	'g' => [0,3],
    	'b' => [0,4],
    	'j' => [0,5],
    	'l' => [0,6],
    	'u' => [0,7],
    	'y' => [0,8],
    	'p' => [0,9],
    	'a' => [1,0],
    	'r' => [1,1],
    	's' => [1,2],
    	't' => [1,3],
    	'd' => [1,4],
    	'h' => [1,5],
    	'n' => [1,6],
    	'e' => [1,7],
    	'i' => [1,8],
    	'o' => [1,9],
    	'z' => [2,0],
    	'x' => [2,1],
    	'c' => [2,2],
    	'v' => [2,3],
    	';' => [2,4],
    	'k' => [2,5],
    	'm' => [2,6],
    	',' => [2,7],
    	'.' => [2,8],
    	'\'' => [2,9]
    }

    @klausler2 = {
    	'q' => [0,0],
    	'g' => [0,1],
    	'u' => [0,2],
    	'y' => [0,3],
    	'k' => [0,4],
    	'.' => [0,5],
    	'm' => [0,6],
    	'c' => [0,7],
    	'f' => [0,8],
    	'b' => [0,9],
    	'i' => [1,0],
    	'o' => [1,1],
    	'e' => [1,2],
    	'h' => [1,3],
    	'd' => [1,4],
    	'r' => [1,5],
    	'n' => [1,6],
    	't' => [1,7],
    	'a' => [1,8],
    	's' => [1,9],
    	'z' => [2,0],
    	'x' => [2,1],
    	'\'' => [2,2],
    	'v' => [2,3],
    	';' => [2,4],
    	'w' => [2,5],
    	'l' => [2,6],
    	'p' => [2,7],
    	',' => [2,8],
    	'j' => [2,9]
    }

    @capewell2 = {
    	'q' => [0,0],
    	'y' => [0,1],
    	'h' => [0,2],
    	'f' => [0,3],
    	'b' => [0,4],
    	'j' => [0,5],
    	'm' => [0,6],
    	'l' => [0,7],
    	'u' => [0,8],
    	',' => [0,9],
    	'i' => [1,0],
    	'e' => [1,1],
    	'n' => [1,2],
    	's' => [1,3],
    	'c' => [1,4],
    	'd' => [1,5],
    	't' => [1,6],
    	'r' => [1,7],
    	'a' => [1,8],
    	'o' => [1,9],
    	'x' => [2,0],
    	'z' => [2,1],
    	'p' => [2,2],
    	'v' => [2,3],
    	';' => [2,4],
    	'k' => [2,5],
    	'g' => [2,6],
    	'w' => [2,7],
    	'.' => [2,8],
    	'\'' => [2,9]
    }

    @arensito2 = {
    	'q' => [0,0],
    	'l' => [0,1],
    	'u' => [0,2],
    	'f' => [0,3],
    	'b' => [0,4],
    	'k' => [0,5],
    	'm' => [0,6],
    	'c' => [0,7],
    	'y' => [0,8],
    	'.' => [0,9],
    	'a' => [1,0],
    	'r' => [1,1],
    	'e' => [1,2],
    	'n' => [1,3],
    	'h' => [1,4],
    	'd' => [1,5],
    	't' => [1,6],
    	's' => [1,7],
    	'i' => [1,8],
    	'o' => [1,9],
    	'z' => [2,0],
    	'x' => [2,1],
    	',' => [2,2],
    	'v' => [2,3],
    	'j' => [2,4],
    	'p' => [2,5],
    	'w' => [2,6],
    	'g' => [2,7],
    	';' => [2,8],
    	'\'' => [2,9]
    }

    @nisa2 = {
    	'q' => [0,0],
    	'w' => [0,1],
    	'u' => [0,2],
    	'g' => [0,3],
    	'b' => [0,4],
    	'k' => [0,5],
    	'h' => [0,6],
    	'y' => [0,7],
    	'c' => [0,8],
    	',' => [0,9],
    	'o' => [1,0],
    	'r' => [1,1],
    	'e' => [1,2],
    	't' => [1,3],
    	'd' => [1,4],
    	'l' => [1,5],
    	'n' => [1,6],
    	'i' => [1,7],
    	's' => [1,8],
    	'a' => [1,9],
    	'z' => [2,0],
    	'x' => [2,1],
    	'\'' => [2,2],
    	'v' => [2,3],
    	';' => [2,4],
    	'f' => [2,5],
    	'm' => [2,6],
    	'p' => [2,7],
    	'.' => [2,8],
    	'j' => [2,9]
    }

    @oist2 = {
    	'.' => [0,0],
    	'y' => [0,1],
    	'c' => [0,2],
    	'g' => [0,3],
    	'b' => [0,4],
    	'j' => [0,5],
    	'h' => [0,6],
    	'u' => [0,7],
    	'w' => [0,8],
    	',' => [0,9],
    	'o' => [1,0],
    	'i' => [1,1],
    	's' => [1,2],
    	't' => [1,3],
    	'd' => [1,4],
    	'l' => [1,5],
    	'n' => [1,6],
    	'e' => [1,7],
    	'r' => [1,8],
    	'a' => [1,9],
    	'z' => [2,0],
    	'x' => [2,1],
    	'v' => [2,2],
    	'p' => [2,3],
    	'q' => [2,4],
    	'f' => [2,5],
    	'm' => [2,6],
    	'k' => [2,7],
    	'\'' => [2,8],
    	';' => [2,9]
    }

    @evolved1 = {
    	'k' => [0,0],
    	'g' => [0,1],
    	'l' => [0,2],
    	'd' => [0,3],
    	'b' => [0,4],
    	'j' => [0,5],
    	'h' => [0,6],
    	'u' => [0,7],
    	'f' => [0,8],
    	'.' => [0,9],
    	'r' => [1,0],
    	'o' => [1,1],
    	't' => [1,2],
    	's' => [1,3],
    	'w' => [1,4],
    	'm' => [1,5],
    	'n' => [1,6],
    	'e' => [1,7],
    	'a' => [1,8],
    	'i' => [1,9],
    	'z' => [2,0],
    	'x' => [2,1],
    	'v' => [2,2],
    	'c' => [2,3],
    	'q' => [2,4],
    	'y' => [2,5],
    	'p' => [2,6],
    	',' => [2,7],
    	'\'' => [2,8],
    	';' => [2,9]
    }

    @dvorak1 = {
    	'\'' => [0,0],
    	',' => [0,1],
    	'.' => [0,2],
    	'p' => [0,3],
    	'y' => [0,4],
    	'f' => [0,5],
    	'g' => [0,6],
    	'c' => [0,7],
    	'r' => [0,8],
    	'l' => [0,9],
    	'a' => [1,0],
    	'o' => [1,1],
    	'e' => [1,2],
    	'u' => [1,3],
    	'i' => [1,4],
    	'd' => [1,5],
    	'h' => [1,6],
    	't' => [1,7],
    	'n' => [1,8],
    	's' => [1,9],
    	';' => [2,0],
    	'q' => [2,1],
    	'j' => [2,2],
    	'k' => [2,3],
    	'x' => [2,4],
    	'b' => [2,5],
    	'm' => [2,6],
    	'w' => [2,7],
    	'v' => [2,8],
    	'z' => [2,9]
    }

    ##########################################################################
    @best_keyboard_count = 0 #number of repeats so far; DO NOT CHANGE
    @best_keyboard_rounds = 0 #number of loops so far; DO NOT CHANGE
    @best_allstar_count = 0 #number of repeats in allstar round; DO NOT CHANGE
    @best_keyboard_count_total = 6  #total full cycles
    @layoutnum = 64 #layouts first created
    @best_layout_count_total = 12 #total mutation rounds within a cycle
    @best_allstar_count_total = 64 #total allstar mutation rounds
    @allstarscore = 9999999 # the score required to finish
    ##########################################################################


    @best_keyboards = []

    def make_keyboard(hash)
    	keyboard = Keyboard.new
    	keyboard.keyboard = hash
    	keyboard.score = @scorer.score_file(keyboard)
    	@best_keyboards.push(keyboard)
    	puts "THIS KEYBOARD WILL BE SPLICED INTO THE FINAL ROUND: "
    	puts "#{keyboard}"
    	keyboard
    end

    #   these were made by people
    @colemak = make_keyboard(@colemak1)
    #@klausler = make_keyboard(@klausler1)
    @capewell = make_keyboard(@capewell1)
    @arensito = make_keyboard(@arensito1)
    #@dvorak = make_keyboard(@dvorak1)
    @nisa = make_keyboard(@nisa1)
    #@oist = make_keyboard(@oist1)
    #@tero = make_keyboard(@tero1)

    #   these were made by the computer
    #@evolved = make_keyboard(@evolved1)
    #@ccolemak = make_keyboard(@colemak2)
    #@cklausler = make_keyboard(@klausler2)
    #@ccapewell = make_keyboard(@capewell2)
    #@cnisa = make_keyboard(@nisa2)
    #@carensito = make_keyboard(@arensito2)
    #@evolved = make_keyboard(@evolved1)

    def winner
    	puts "****************************"
    	puts "*******WINNING LAYOUT*******"
    	puts "*******WINNING LAYOUT*******"
    	puts "*******WINNING LAYOUT*******"
    	puts "*************won************"
    	puts "****************************"
    end

    def sort(keyboards)
    	keyboards.sort_by { |k|
    		k.score['score']
    	}
    end

    def score(keyboards)
    	keyboards.each { |k|
    		k.score = @scorer.score_file(k)
    	}
    end

    def scoreone(k)
    	k.score = @scorer.score_file(k)
    end


    @bestkeyboard = nil

    while (@best_keyboard_count < @best_keyboard_count_total)
    	@best_keyboard_rounds += 1

    	@best_keyboards = sort(@best_keyboards)
    	if @bestkeyboard == @best_keyboards[0]
    		@best_keyboard_count += 1
    	else
    		@best_keyboard_count = 0
    	end
    	@bestkeyboard = @best_keyboards[0]

    	@keyboards = []

    	@layoutnum.times {
    		keyboard = Keyboard.new
    		@keyboards.push(keyboard)
    	}

    	score(@keyboards)

    	@keyboards = sort(@keyboards)

    	@roundcount = 0
    	@best_layout_count = 0

    	while (@best_layout_count < @best_layout_count_total)
    		@roundcount += 1
    		@bestlayout = @keyboards[0]
    		@keyboards = @keyboards[0..(@keyboards.length/2)-1]

    		new_keyboards = []
    		@keyboards.each { |k|
    			new_keyboards.push(k.mutate)
    		}

    		score(new_keyboards)
			
    		@keyboards = @keyboards.concat(new_keyboards)
    		@keyboards = sort(@keyboards)

    		if @bestlayout == @keyboards[0]
    			@best_layout_count += 1
    		else
    			@best_layout_count = 0
    		end

    		puts
    		puts "#{@keyboards.length} keyboards remaining"
    		puts "round #{@best_keyboard_rounds}, cycle #{@best_keyboard_count}/#{@best_keyboard_count_total}: "
    		puts "best layout after mutation round #{@roundcount} and #{@best_layout_count}/#{@best_layout_count_total} repeats: "
    		puts @keyboards[0]

    	end

    	winner
    	puts @keyboards[0]
	
    	@best_keyboards.push(@keyboards[0])

    end


    # # # ### ####### # #

    puts "all star round commence"

    puts "splicing in the best layouts"

    @best_keyboards = sort(@best_keyboards)

    @allstarcount = 0
    while (@best_allstar_count < @best_allstar_count_total) or (@best_keyboards[0].score["score"] > @allstarscore)
      @allstarcount += 1
      @bestlayout = @best_keyboards[0]
      @best_keyboards = @best_keyboards[0..(@best_keyboards.length/2)-1]

      new_keyboards = []
      @best_keyboards.each { |k|
      	new_keyboards.push(k.mutate)
      }

      score(new_keyboards)

      @best_keyboards = @best_keyboards.concat(new_keyboards)
      @best_keyboards = sort(@best_keyboards)

      if @bestlayout == @best_keyboards[0]
      	@best_allstar_count += 1
      else
      	@best_allstar_count = 0
      end

      puts
      puts "best keyboard after #{@allstarcount} all star rounds and #{@best_allstar_count}/#{@best_allstar_count_total} repeats:"
      puts @best_keyboards[0]

    end


    winner
    puts @best_keyboards[0]

    @best_keyboards[0]
  end
end

a = Algorithm.new
a.run