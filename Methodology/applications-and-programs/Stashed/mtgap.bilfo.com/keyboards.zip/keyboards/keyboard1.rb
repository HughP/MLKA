class Keyboard
	
	attr_accessor :keyboard, :score, :id, :chars, :deleter
	
	@@chars = [
		'e',
		't',
		'a',
		'o',
		'i',
		'n',
		's',
		'r',
		'h',
		'l',
		'd',
		'c',
		'u',
		'm',
		'f',
		'g',
		'y',
		'w',
		'p',
		'b',
		'.',
		'v',
		',',
		'k',
		'\'',
		'x',
		'j',
		'q',
		'z',
		'-'
		]

		@@positions = [
			[0,0],
			[0,1],
			[0,2],
			[0,3],
			[0,4],
			[0,5],
			[0,6],
			[0,7],
			[0,8],
			[0,9],
			[1,0],
			[1,1],
			[1,2],
			[1,3],
			[1,4],
			[1,5],
			[1,6],
			[1,7],
			[1,8],
			[1,9],
			[2,0],
			[2,1],
			[2,2],
			[2,3],
			[2,4],
			[2,5],
			[2,6],
			[2,7],
			[2,8],
			[2,9]
		]

	# [row, finger]

	def initialize
		@score = 0
		@id = 0
		@keyboard = random_keyboard
		@deleter = 0
		@chars = @@chars
	end

	def random_keyboard
		charstop = @@chars[10..19].clone.sort_by {rand}
		charshome = @@chars[0..9].clone.sort_by {rand}
		charsbot = @@chars[20..29].clone.sort_by {rand}
		rand_keyboard = {}
		charstop.each_index { |i|
			rand_keyboard[charstop[i]] = @@positions[i]
		}
		charshome.each_index { |i|
			rand_keyboard[charshome[i]] = @@positions[i+10]
		}
		charsbot.each_index { |i|
			rand_keyboard[charsbot[i]] = @@positions[i+20]
		}
		rand_keyboard
	end
	
	def to_s
	"#{score_to_s}\n#{keyboard_to_s}"
	end
	
	def score_to_s # this is where it prints out each stat
		"score: #{score['score']}, effort: #{score['effort']}, handcount: #{score['handcount']}, fingercount: #{score['fingercount']}, indexcount: #{score['indexcount']}, handwarpcount: #{score['handwarpcount']}, jumphomecount: #{score['jumphomecount']}, rowchangecount: #{score['rowchangecount']}, inrollcount: #{score['inrollcount']}, outrollcount: #{score['outrollcount']}, " 
#		"lpinky: #{score['lpinky']}, lring: #{score['lring']}, lmiddle: #{score['lmiddle']}, lindex: #{score['lindex']}, rindex: #{score['rindex']}, rmiddle: #{score['rmiddle']}, rring: #{score['rring']}, rpinky: #{score['rpinky']}"
	end

	def keyboard_to_s
		s = ""
		keys = @keyboard.keys.sort_by { |k|
			@keyboard[k]
		}
		row = 0
		keys.each { |k|
			if row != @keyboard[k][0]
				s += "\n"
				row += 1
			end
#			s += "#{k}:#{@keyboard[k]} "
			s += " #{k}"
		}
		s
	end
	
	def mutate
		k = @keyboard.clone
		switch1num = rand(k.length-1)
		switch2num = rand(k.length-1)
		key1 = k.keys[switch1num]
		key2 = k.keys[switch2num]
		while ( (key1 == ("e" or "t" or "a" or "o" or "i" or "n")) and (switch2num != (10 or 11 or 12 or 13 or 16 or 17 or 18 or 19)) or (key2 == ("e" or "t" or "a" or "o" or "i" or "n")) and (switch1num != (10 or 11 or 12 or 13 or 16 or 17 or 18 or 19)))
			switch1num = rand(k.length-1)
			switch2num = rand(k.length-1)
			key1 = k.keys[switch1num]
			key2 = k.keys[switch2num]
		end
		position = k[key1]
		k[key1] = k[key2]
		k[key2] = position
		keyboard = Keyboard.new
		keyboard.keyboard = k
		keyboard
	end
	
	
end