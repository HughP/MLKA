/*
 * Created on Nov 13, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
//package analyze;

import junit.framework.*;

/**
 * @author Michael
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class KeyCombosTest extends TestCase{

	private KeyCombos kc = new KeyCombos();
	
	protected void setUp() {
		kc.add(new String("aa"));
		kc.add(new String("aa"));
		kc.add(new String("bb"));
		kc.add(new String("cc"));
		kc.add(new String("cc"));
		kc.add(new String("cc"));
	}
	
	public void testAdd(){
		//	tests the 'add' used in setUp
		Assert.assertEquals(3, kc.size()); //"aa", "bb", and "cc"
		Assert.assertEquals(2, kc.getCount("aa"));
		Assert.assertEquals(1, kc.getCount("bb"));
		Assert.assertEquals(2, kc.getCount("aa"));
		Assert.assertEquals(3, kc.getCount("cc"));
	}
	
	public void testSort(){
		
		kc.sort();
		
		Assert.assertEquals(3, kc.m_comboCountsVector.size());
		
		Assert.assertTrue( ( ((KeyCombo)kc.m_comboCountsVector.get(0)).getCombo().equals("cc") ) );
		Assert.assertEquals(3, ((KeyCombo)kc.m_comboCountsVector.get(0)).getCount());
		Assert.assertTrue( ( ((KeyCombo)kc.m_comboCountsVector.get(1)).getCombo().equals("aa") ) );
		Assert.assertEquals(2, ((KeyCombo)kc.m_comboCountsVector.get(1)).getCount());
		Assert.assertTrue( ( ((KeyCombo)kc.m_comboCountsVector.get(2)).getCombo().equals("bb") ) );
		Assert.assertEquals(1, ((KeyCombo)kc.m_comboCountsVector.get(2)).getCount());
	}

}
