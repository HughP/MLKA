/*
 * Created on Nov 13, 2005
 *
 */
//package analyze;

import java.util.Comparator;

/**
 * @author Michael
 *
 */
public class KeyCombo {

	public static final int PRINT_BASIC = 0;
	public static final int PRINT_PRETTY = 1;

	private static int m_printStyle;

	private String m_combo;
    private int m_count;

    KeyCombo(String combo, int count){
    	m_combo = combo;
        m_count = count;
    }

    public String getCombo(){
    	return m_combo;
    }
    public int getCount(){
        return m_count;        
    }

    public static void setPrintStyle(int printStyle){
    	//don't bother checking if it's invalid
    	m_printStyle = printStyle;
    }

    public String toString(){
        String keysStr="";

    	if (PRINT_BASIC == m_printStyle){
    		keysStr = new String(m_combo) + "\r\n" + m_count;	
    	}else if (PRINT_PRETTY == m_printStyle){
    		keysStr = "(" + new String(m_combo) + ", " + m_count + ")";
    	}

    	return keysStr;

    }

}

/*==============================================================================
==  KeyComboCountComparator  ======================  KeyComboCountComparator  ==
================================================================================
==============================================================================*/
class KeyComboCountComparator  implements Comparator {
    
    public KeyComboCountComparator() {}
    
    public int compare(Object combo1, Object combo2) {
        
        int int1 = ((KeyCombo)combo1).getCount();
        int int2 = ((KeyCombo)combo2).getCount();
        
        if (int1<int2) return 1;
        if (int1>int2) return -1;
        return 0;
        
    }
} 
