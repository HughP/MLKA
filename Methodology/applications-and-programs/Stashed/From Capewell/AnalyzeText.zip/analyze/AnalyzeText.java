//package analyze; 

import java.io.FileNotFoundException;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;
//import java.util.Collections;
//import java.util.Comparator;
//import java.util.Enumeration;
//import java.util.TreeMap;
//import java.util.Vector;

/*
 * Created on 6-Aug-2004
 */

/**
 * @author Michael Capewell (2004)
 */

/*==============================================================================
==  class AnalyzeText  ==================================  class AnalyzeText  ==
================================================================================

Created on 6-Aug-2004

@author Michael Capewell (2004)

There are 2 things you might need to do before using this program.


This program has been modified from it's original version, somewhat, in order to 
work with my keyboard evolution program.  It was originally written to show me
the most common letters and combinations, to learn how to teach typing better.

The added lines are:
	//THIS ONLY WORKS PROPERLY WITH "\r\n" AND NOT WITH UNIX- OR MAC-STYLE "\n"
	if ((m_keys[2] == '\r') && (m_keys[3] == '\n')){
		m_keys[2] = ' ';
		m_keys[3] = ' ';
	}
and 1- and 4-key combos have been ignored.
                
To use a UNIX- or Mac-formatted text file, you will want to write a small 
program that either:
  1) replaces '\n' or '\r' with "\r\n".
  2) adds two spaces after every occurence of '\n' or '\r'.
and then run the modified file through this program.

You will also need to fill the file "keycomboinput.txt" with some text to analyze

==============================================================================*/


public class AnalyzeText {
    
    private static final int m_printStyle = KeyCombos.PRINT_BASIC; 
	
    private static void println(String s){
        System.out.println(s);
    }
    
    public static void main(String[] args) { 

        int charactersRead = 0;
        char[] m_keys = new char[4];
        FileReader fr;
        KeyCombos keyCombos = new KeyCombos();
        //KeyCombos threeKeyCombos = new KeyCombos(3);

        //open a file stream
        try{
            fr = new FileReader("keycomboinput.txt");
        }catch(FileNotFoundException e){
            println("keycomboinput.txt not found");
            return;
        }

        try{

            //fill prev slots with spaces.
            m_keys[1] = ' '; //Character.toLowerCase((char)fr.read()) ; //assume these two are never -1
            m_keys[2] = ' '; //Character.toLowerCase((char)fr.read());
            m_keys[3] = ' '; // Character.toLowerCase((char)fr.read());
            charactersRead = 0;

            do{
                //shift over the previously gotten characters and input one more into [3]
                m_keys[0] = m_keys[1];
                m_keys[1] = m_keys[2];
                m_keys[2] = m_keys[3];
                m_keys[3] = Character.toLowerCase((char)fr.read());
                charactersRead ++;
                
                //THIS ONLY WORKS PROPERLY WITH "\r\n" AND NOT WITH UNIX- OR MAC-STYLE "\n"
                if ((m_keys[2] == '\r') && (m_keys[3] == '\n')){
                	m_keys[2] = ' ';
                	m_keys[3] = ' ';
                }

                //print out a bit of feedback..
                if (charactersRead % 1024 == 0){
                    println("read " + (charactersRead/1024)+ "kB");
                }

                if (m_keys[0]>=' ' && m_keys[0]<='}'){
                    char[] onekeys = {m_keys[0]};
                    keyCombos.add(new String(onekeys));

                    if (m_keys[1]>=' ' && m_keys[1]<='}'){
	                    char[] twokeys = {m_keys[0], m_keys[1]};
	                    keyCombos.add(new String(twokeys));

		                if (m_keys[2]>=' ' && m_keys[2]<='}'){
		                	//we want to:
		                	//			keep "  ?" 
		                    //			keep "? ?"
		                	if (m_keys[0]!=' ' && m_keys[1]==' ' && m_keys[2]!=' '){ //"? ?"
			                	char[] threekeys = {m_keys[0], m_keys[1], m_keys[2]};
			                    keyCombos.add(new String(threekeys));
		                    }else if (' ' == m_keys[0] && ' ' == m_keys[1]){ //"  ?"
			                	char[] threekeys = {m_keys[0], m_keys[1], m_keys[2]};
			                    keyCombos.add(new String(threekeys));
		                    }/*else if (' ' != m_keys[0] && ' ' != m_keys[2]){ //"???" -> "? ?"
		                		char[] threekeys = {m_keys[0], ' ', m_keys[2]};
		                		keyCombos.add(new String(threekeys));
		                	}*/


		                   	if (m_keys[3]>=' ' && m_keys[3]<='}'){
		                       	if (m_keys[2] == (char)-1) break;
		                           //char[] fourkeys = {m_keys[0], m_keys[1], m_keys[2], m_keys[3]};
		                           //KeyCombos.CountCombo(fourkeys);
		                   	}
		                }
                    }
                }
                if (m_keys[3] == (char)-1) break;

            }while(true);

        }catch(IOException e){
            println("ioexception reading from file");
            return;
        }

        try{
            fr.close();
        }catch(IOException e){

        }
        System.out.println("done reading, gonna print out...");
        //System.out.println(KeyCombos.toString());

        KeyCombos.setPrintStyle(m_printStyle);
        keyCombos.toFile("keycombooutput.txt");

        System.out.println("Done printing out!");

    }
}
