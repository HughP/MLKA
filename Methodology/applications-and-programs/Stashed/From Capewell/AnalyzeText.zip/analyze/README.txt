
AnalyzeText (Nov 14, 2005)

by
(c) Michael Capewell 2005
http://www.geocities.com/smozoma/programming


---------------------------
Table of Contents
-----------------
1.0 About
2.0 Compiling and Modifying
3.0 Legalish Stuff
---------------------------


---------
1.0 About
---------

This program reads in text from "keycomboinput.txt," counts the occurrences of key combinations, and outputs the results to "keycomboinput.txt"

The following keys are considered, as well as the space key:
!"#$%&'()*+,-./0123456789:;<=>?@
ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`
abcdefghijklmnopqrstuvwxyz{|}

Note that all letters are converted to lower-case.

This version is set up to count the occurrences of:
 * single keys
 * pairs of keys, including the space key.
 * [non-space][space][non-space], but not 3 non-space 
   characters in a row.
 * [space][space][non-space]
     - special case:  For windows formatted text file 
       (where a new line is indicated by \n\r), \n\r is
       converted into 2 spaces and is included in the
       count for [space][space][non-space]

Note:  The program starts by adding 3 extra spaces at the start of 
       the file.

To modify these rules, see lines 82-84, 95-99, and 106-137 of AnalyzeText.java.
Sorry about the lack of commenting in the code.


---------------------------
2.0 Compiling and Modifying
---------------------------

There are 3 java files for the program and 1 java file that tests one of the classes.  You do not need to compile the test file.

Program files:
AnalyzeText.java
KeyCombo.java
KeyCombos.java

Test files:
KeyCombosTest.java

To compile the test file, you will need JUnit (http://www.junit.org/index.htm).  

I don't have the classes set up as a 'package,' since it was giving me compilation troubles when compiling using the included .BAT file.

The lines you'll probably want to modify are lines 82-84, 95-99, and 106-137 of AnalyzeText.java.
Sorry about the lack of commenting in the code.


------------------
3.0 Legalish Stuff
------------------

This program is not guaranteed to be correct or useful.
You may modify this program as you wish or incorporate it or parts of it into another program, but if you distribute something using any of this code, it must include credit for me (including my name and website URL) where credit is due.  Thanks!