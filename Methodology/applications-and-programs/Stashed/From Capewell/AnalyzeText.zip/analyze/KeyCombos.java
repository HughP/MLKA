/*==============================================================================
==  class KeyCombos  ======================================  class KeyCombos  ==
================================================================================
Usage:
Use 'add(String combo)' to add and count combo occurrences.
Use 'toFile(String filename)' to output the results to a file.
Those are the only things you can count on to work!
==============================================================================*/


//package analyze;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

/*
 * Created on Nov 13, 2005
 *
 */

/**
 * @author Michael
 *
 */
public class KeyCombos{

	public static final int PRINT_BASIC = 0;
	public static final int PRINT_PRETTY = 1;
	
	private static int m_printStyle;

    private TreeMap m_comboCountsMap = new TreeMap();
    protected Vector m_comboCountsVector = new Vector();
    
    KeyCombos(){
    	m_printStyle = PRINT_BASIC;
    }
    
    public void add(String keys){

        /*	check if the string(key) is in the treemap.
         * 	if yes, increment the associated value in the map
         * 	if no, add to the map with a value of 1.
         */
    	if (!m_comboCountsMap.containsKey(keys)){
    		m_comboCountsMap.put(keys, new Integer(1));
    	}else{
    		m_comboCountsMap.put(keys, new Integer( ((Integer)m_comboCountsMap.get(keys)).intValue()+1) );
    	}
        
        return;
    }
    public int size(){
    	return m_comboCountsMap.size();
    }
    public int getCount(String keys){
    	return ((Integer)m_comboCountsMap.get(keys)).intValue();
    }
    
    protected void sort(){

    	m_comboCountsVector.clear();
    	String combo;
    	int count;
    	
    	Set mapentries = m_comboCountsMap.entrySet();
    	for (Iterator it = mapentries.iterator(); it.hasNext();){
    		Map.Entry entry = (Map.Entry)it.next();
    		combo = (String)((entry).getKey());
    		count = ( ((Integer)entry.getValue()) ).intValue();
    		m_comboCountsVector.add(new KeyCombo(combo, count));			
    	}
    	Collections.sort(m_comboCountsVector, new KeyComboCountComparator());
    }
    
    public static void setPrintStyle(int printStyle){
    	//don't bother checking if it's invalid
    	m_printStyle = printStyle;
    	KeyCombo.setPrintStyle(m_printStyle);
    }
    
    public void toFile(String filename){
        
    	/*
    	 * Sort by count/value in the TreeMap into a pair of vectors 
    	 */
    	sort();
    	
    	/*
    	 * Output to file
    	 */
        try{
            FileWriter fw = new FileWriter(filename);
            for (int i=0; i<=m_comboCountsVector.size()-1; i++){
            	if (PRINT_BASIC == m_printStyle){
            		fw.write( ((KeyCombo)m_comboCountsVector.elementAt(i)).toString() );	
            	}else if (PRINT_PRETTY == m_printStyle){
            		fw.write((i+1) + "   " + ((KeyCombo)m_comboCountsVector.elementAt(i)).toString());
            	}
                fw.write("\r\n");
            }
            //fw.write(this.toString());
            fw.close();
        }catch(IOException e){
        }
    }
    
/*    public String toString(){
        
        String str = "";
        for (int i=0; i<=m_comboCountsVector.size()-1; i++){
        	if (PRINT_BASIC == m_printStyle){
        		//str = str.concat(((KeyCombo)combos.elementAt(i)).toString());	
        	}else if (PRINT_PRETTY == m_printStyle){
        		//str = str.concat((i+1) + "   " + ((KeyCombo)combos.elementAt(i)).toString());
        	}
        	str += "\r\n";
        }
        return str;
    }
*/

    public static void main(String[] args) {
    	KeyCombos kc = new KeyCombos();
    	kc.add(new String("aa"));
		kc.add(new String("aa"));
		kc.add(new String("bb"));
		kc.add(new String("cc"));
		kc.add(new String("cc"));
		kc.add(new String("cc"));
		System.out.println(kc.getCount("aa"));
		//kc.toFile("moo.txt");
		kc.sort();
		System.out.println(kc.getCount("aa"));
		kc.toFile("moo.txt");

    }

}
