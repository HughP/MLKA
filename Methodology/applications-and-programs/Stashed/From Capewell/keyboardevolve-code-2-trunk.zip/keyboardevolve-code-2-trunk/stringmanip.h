/*==============================================================================
stringmanip.h                                                      stringmanip.h
================================================================================
A little utility for converting between strings and numbers
==============================================================================*/

#include <string>
#include <sstream>
#include <iostream>

/*==============================================================================
to_string															   to_string
================================================================================
from http://www.codeguru.com/forum/showthread.php?s=&threadid=231056

RETURN: string version of a number

INPUT : T t		: The number you wish to convert to a string.
		ios_base & (*f)(ios_base&)	: The number base to use (std::hex, 
		                                          std::dec or std::oct).
USAGE : e.g.: 
		cout << to_string<long>(123456, std::dec);
==============================================================================*/
template <class T>
std::string to_string(T t, std::ios_base & (*f)(std::ios_base&)){
   std::ostringstream oss;
   oss << f << t;
   return oss.str();
}

/*==============================================================================
from_string															 from_string
================================================================================
from http://www.codeguru.com/forum/showthread.php?s=&threadid=231054

OUTPUT: T &t		: The number is returned by reference.

INPUT : T &t		: The reference to the numerical variable you wish to get.
		string &s   : A string version of the number.
		ios_base & (*f)(ios_base&)	: The number base to use (std::hex, 
		                                          std::dec or std::oct).
USAGE : If you wish to, for example, convert the string hex number "ff" to an 
		int value:
		e.g.:
		if(from_string<int>(i, string("ff"), std::hex)){
			cout << i;
		}else{
			cout << "from_string failed";
		}
==============================================================================*/
template <class T>
bool from_string(T &t, const std::string &s, std::ios_base & (*f)(std::ios_base&)){
   std::istringstream iss(s);
   return !(iss>>f>>t).fail();
}
