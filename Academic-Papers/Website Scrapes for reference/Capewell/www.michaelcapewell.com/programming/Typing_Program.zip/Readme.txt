Typing program (v1.0) created by Michael Capewell (2004)
  mcapewell@gmail.com
  http://www.geocities.com/smozoma

------------
INSTALLATION
------------

Simply unzip all the files to any desired directory and run "Typing.exe"

If Typing.exe will not run, you need to install the Visual Basic 6 run-time DLLs:  
http://download.microsoft.com/download/5/a/d/5ad868a0-8ecd-4bb0-a882-fe53eb7ef348/VB6.0-KB290887-X86.exe

------------

This package includes just the first 10 lessons, teaching 13 letters and 2 punctuation marks.  For more lessons, email me at mcapewell@gmail.com and if I ever get around to making more lessons, I will send them to you.

I really need to shorten some of the lessons by breaking them up.  Eventually...