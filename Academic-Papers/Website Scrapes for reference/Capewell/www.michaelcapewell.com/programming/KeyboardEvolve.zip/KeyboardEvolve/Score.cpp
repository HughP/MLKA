/*==============================================================================
Score.cpp                                                              Score.cpp
================================================================================

Created: 2005/06/10 (Jun 10, 2005)
Author : Michael Capewell (smozoma@yahoo.com)

This is an object representing the score for one keyboard layout.

YES IT'S A MESS -- needs refactoring rather badly
                   It was a last-minute addition.

==============================================================================*/

/*
TODO:10:
*   make the scoring parameters set-able via INI fileso we don't need to 
    hard-code them in the CPP file
*/

#include "Score.h"

#include <string>
#include <sstream>
#include <iomanip>

using std::vector;

bool sameHand(int col1, int col2);
bool sameCol(int col1, int col2);

//PENALTY PROTOTYPES
void pinkyFingFunc(ComboInfo &ci, Penalty &p);
void ringFingFunc(ComboInfo &ci, Penalty &p);
void AwkwardCtrKeyFunc(ComboInfo &ci, Penalty &p);
void reachToCtrFunc(ComboInfo &ci, Penalty &p);
void closeKeysFunc(ComboInfo &ci, Penalty &p);
void adjacentKeysFunc(ComboInfo &ci, Penalty &p);
void changeRowFunc(ComboInfo &ci, Penalty &p);
void sameFingFunc(ComboInfo &ci, Penalty &p);
void jumpHomeRowFunc(ComboInfo &ci, Penalty &p);
void jumpHomeRowExceptionsFunc(ComboInfo &ci, Penalty &p);
void CFunc(ComboInfo &ci, Penalty &p);
void XFunc(ComboInfo &ci, Penalty &p);
void RFunc(ComboInfo &ci, Penalty &p);
void QFunc(ComboInfo &ci, Penalty &p);
void rollingBonusFunc(ComboInfo &ci, Penalty &p);

static float SPACEKEY_REDUCTION_FRACTION;

Score::Score(void) 
{
}

Score::~Score(void)
{
}

/*==============================================================================
init															            init
================================================================================
==============================================================================*/
void Score::init(){

	/* THINGS TO SET BEFORE RUNNING */ 

	//0 means spaces have no effect, i.e., it's as though the text had all spaces removed.
    //1 means a space is like starting typing all over again.
	SPACEKEY_REDUCTION_FRACTION = 0.50;

	Penalty p;

	m_penalties.clear();

	p.occurrences = 0;
	p.spacekeyReductions = 0;

	p.description = "QS QD QF QG PJ PK PL PH";
	p.inEffect = true;
	p.weight = 20;
	p.penaltyFunc = QFunc;
	m_penalties.push_back(p);

	p.description = "DR DT KU KY";
	p.inEffect = true;
	p.weight = 18;
	p.penaltyFunc = RFunc;
	m_penalties.push_back(p);

	p.description = "XA XD XF XG .; .K .J .H";
	p.inEffect = true;
	p.weight = 18;
	p.penaltyFunc = XFunc;
	m_penalties.push_back(p);

	p.description = "CA CS CF CG ,J ,K ,; ,H";
	p.inEffect = true;
	p.weight = 22;
	p.penaltyFunc = CFunc;
	m_penalties.push_back(p);

	p.description = "Using the pinky finger off the home row + a key on the same hand";
	p.inEffect = true;
	p.weight = 14;
	p.penaltyFunc = pinkyFingFunc;
	m_penalties.push_back(p);

	p.description = "Using the ring finger on the bottom row";
	p.inEffect = true;
	p.weight = 10;
	p.penaltyFunc = ringFingFunc;
	m_penalties.push_back(p);

	p.description = "Using the awkward Y and B keys";
	p.inEffect = true;
	p.weight = 20;
	p.penaltyFunc = AwkwardCtrKeyFunc;
	m_penalties.push_back(p);

	p.description = "Reaching to the centre col w/o switching hands";
	p.inEffect = true;
	p.weight = 20 ;
	p.penaltyFunc = reachToCtrFunc;
	m_penalties.push_back(p);

/*	p.description = "Reaching to an awkward key w/o switching hands";
	p.inEffect = REACH_TO_AWKWARD_KEY_WITHOUT_SWITCHING_HANDS_IN_EFFECT;
	p.weight = REACH_TO_AWKWARD_KEY_WITHOUT_SWITCHING_HANDS_WEIGHT;
	p.penaltyFunc = ;
	m_penalties.push_back(p);
*/
	p.description = "Bonus for using dif-finger keys on same hand (w/o reaching)";
	p.inEffect = false;
	p.weight = -1;
	p.penaltyFunc = closeKeysFunc;
	m_penalties.push_back(p);

	p.description = "Bonus for using adjacent, dif-finger keys";
	p.inEffect = false;
	p.weight = -1;
	p.penaltyFunc = adjacentKeysFunc;
	m_penalties.push_back(p);

	p.description = "Changing rows on the same hand";
	p.inEffect = true;
	p.weight = 2;
	p.penaltyFunc = changeRowFunc;
	m_penalties.push_back(p);

	p.description = "Using the same finger twice in a row";
	p.inEffect = true;
	p.weight = 20;
	p.penaltyFunc = sameFingFunc;
	m_penalties.push_back(p);

	p.description = "Jumping over the home row on one hand";
	p.inEffect = true;
	p.weight = 30;
	p.penaltyFunc = jumpHomeRowFunc;
	m_penalties.push_back(p);

	p.description = "Using certain home-row-jumping combos penalty reduction";
	p.inEffect = true;
	p.weight = -20;
	p.penaltyFunc = jumpHomeRowExceptionsFunc;
	m_penalties.push_back(p);

	//ROLLING BONUS
	p.description = "Bonus for rolling of fingers on adjacent keys";
	p.inEffect = true;
	p.weight = -10;
	p.penaltyFunc = rollingBonusFunc;
	m_penalties.push_back(p);

}
void Score::reset(){
	init();
}

/*==============================================================================
calculateScore											          calculateScore
================================================================================
==============================================================================*/
void Score::calculateScore(ComboInfo &ci)
{
	for (vector<Penalty>::size_type i = 0; i<m_penalties.size(); i++){
		m_penalties[i].penaltyFunc(ci, m_penalties[i]);
	}
}

inline
bool sameHand(int col1, int col2){
	return ((4>=col1) == (4>=col2));
}
inline
bool sameCol(int col1, int col2){
	return (col1 == col2);
}

/*==============================================================================
getTotalScore											           getTotalScore
================================================================================
==============================================================================*/
const int Score::getTotalScore() const {
	
	int totalScore = 0;

	for (vector<Penalty>::size_type i = 0; i< m_penalties.size(); i++){
		totalScore += (int)(m_penalties[i].inEffect 
			* (m_penalties[i].weight 
			* (m_penalties[i].occurrences - m_penalties[i].spacekeyReductions * SPACEKEY_REDUCTION_FRACTION) ));
	}

	return totalScore;
}

/*==============================================================================
scoreSummary											            scoreSummary
================================================================================
==============================================================================*/
std::string Score::scoreSummary(){

	std::stringstream summary;

	//TODO:1000: factor out the weight when calculating

	for (vector<Penalty>::size_type i = 0; i< m_penalties.size(); i++){
		summary
			<< m_penalties[i].inEffect << " "
			<< std::setw(8) << 
				(int)m_penalties[i].inEffect * m_penalties[i].weight 
				* (m_penalties[i].occurrences 
					- (SPACEKEY_REDUCTION_FRACTION * m_penalties[i].spacekeyReductions))
			<< " (" << m_penalties[i].occurrences << " - " << SPACEKEY_REDUCTION_FRACTION 
			<< "*" << m_penalties[i].spacekeyReductions << ") * " << m_penalties[i].weight
			<< " " << m_penalties[i].description
			<< "\n";
	}

	return summary.str();
}

/*==============================================================================
scoringParameters											   scoringParameters
================================================================================
==============================================================================*/
const std::string Score::scoringParameters(){

	std::stringstream parameters;

	parameters << std::setw(3) << 100*SPACEKEY_REDUCTION_FRACTION << "% space key reduction percent" << "\n";

	for (vector<Penalty>::size_type i = 0; i< m_penalties.size(); i++){
		if (m_penalties[i].inEffect){
			parameters 
			<< std::setw(3) << m_penalties[i].weight
			<< " " << m_penalties[i].description
			<< "\n";
		}
	}

	return parameters.str();
}

/*==============================================================================
Penalty Functions									           Penalty Functions
================================================================================
==============================================================================*/
void pinkyFingFunc(ComboInfo &ci, Penalty &p)
{
	if ((0==ci.cCol || 9==ci.cCol) && (1!=ci.cRow)){
		p.occurrences += ci.penaltyMultiplier;
		if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
		//there is an extra penalty if you use the pinky off the home row 
		//and another key on the same hand
		if (sameHand(ci.cCol, ci.lCol)){
			p.occurrences += ci.penaltyMultiplier;
			if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
		}

	}
}

void ringFingFunc(ComboInfo &ci, Penalty &p)
{
	//Using the ringfinger on the bottom row
	if ((1==ci.cCol || 8==ci.cCol) && (2==ci.cRow)){
		p.occurrences += ci.penaltyMultiplier;
		if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
	}
}

void AwkwardCtrKeyFunc(ComboInfo &ci, Penalty &p)
{
	//Using [0][5] or [2][4] (reaching far to the centre)
	if ((0==ci.cRow && 5==ci.cCol) || (2==ci.cRow && 4==ci.cCol)){
		p.occurrences += ci.penaltyMultiplier;
		if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
	}
}

void reachToCtrFunc(ComboInfo &ci, Penalty &p)
{
	//Penalty if using a centre-column key before or after another key on the same hand (not switching hands)
	//(unless also in that column, since we might as well hit another key while we're out there!)
	if (sameHand(ci.cCol, ci.lCol)){
		if (!sameCol(ci.cCol, ci.lCol) && (4==ci.cCol || 4==ci.lCol || 5==ci.cCol || 5==ci.lCol)){
			p.occurrences += ci.penaltyMultiplier;
			if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
	}	}
}

void closeKeysFunc(ComboInfo &ci, Penalty &p)
{
	if (sameHand(ci.cCol, ci.lCol)){
		//Bonus for hitting close or adjacent different-finger keys
		if ( abs(ci.cRow - ci.lRow) <= 1 ){	//if adjacent or equal rows
			if ( !sameCol(ci.cCol, ci.lCol) && (ci.cCol!=4 && ci.lCol!=4 && ci.cCol!=5 && ci.lCol!=5) ){ //not same col or centre col
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
		}	}
	}
}

void adjacentKeysFunc(ComboInfo &ci, Penalty &p)
{
	if (sameHand(ci.cCol, ci.lCol)){
		//Bonus for hitting close or adjacent different-finger keys
		if ( abs(ci.cRow - ci.lRow) <= 1 ){	//if adjacent or equal rows
			if ( !sameCol(ci.cCol, ci.lCol) && (ci.cCol!=4 && ci.lCol!=4 && ci.cCol!=5 && ci.lCol!=5) ){ //not same col or centre col
				if (abs(ci.cCol-ci.lCol) == 1){		//if adjacent, but not-equal columns 
					//And not both index-finger columns   and not on different hands
					p.occurrences += ci.penaltyMultiplier;
					if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
		}	}	}
	}
}

void changeRowFunc(ComboInfo &ci, Penalty &p)
{
	if (sameHand(ci.cCol, ci.lCol)){
		//Changing row on same hand
		if ( (ci.lRow != ci.cRow)){
			p.occurrences += ci.penaltyMultiplier;
			if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
	}	}
}

void sameFingFunc(ComboInfo &ci, Penalty &p)
{
	//Hitting different keys with the same finger in a row
	if (sameCol(ci.cCol,ci.lCol) && (ci.cRow!=ci.lRow)){//same col, dif row
		p.occurrences += ci.penaltyMultiplier;
		if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
	}else if ((3==ci.cCol && 4==ci.lCol) || (4==ci.cCol && 3==ci.lCol)	 //change of left index fing col
			|| (5==ci.cCol && 6==ci.lCol) || (6==ci.cCol && 5==ci.lCol)){ //change of right index fing col
		p.occurrences += ci.penaltyMultiplier;
		if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
	}
}

void jumpHomeRowFunc(ComboInfo &ci, Penalty &p)
{
	if (sameHand(ci.cCol, ci.lCol)){
		if (abs(ci.cRow-ci.lRow)>=2){		//jumped the home row
			p.occurrences += ci.penaltyMultiplier;
			if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
		}
	}
}

void jumpHomeRowExceptionsFunc(ComboInfo &ci, Penalty &p)
{
	if (sameHand(ci.cCol, ci.lCol)){

		//[2][3] to [0][1] or [0][2] (V to E or W)
		/*if (   (2==ci.lRow && 3==ci.lCol) && ((0==ci.cRow && 1==ci.cCol) || (0==ci.cRow && 2==ci.cCol))
			|| (2==ci.cRow && 3==ci.cCol) && ((0==ci.lRow && 1==ci.lCol) || (0==ci.lRow && 2==ci.lCol)))
		{
			p.occurrences += ci.penaltyMultiplier;
			if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
		}else */

		//MI MO ([2][6] to [0][7]) // or [0][8])
		if ( ((2==ci.lRow && 6==ci.lCol) && ((0==ci.cRow && 7==ci.cCol) /* || (0==ci.cRow && 8==ci.cCol)*/ ))
			||     ((2==ci.cRow && 6==ci.cCol) && ((0==ci.lRow && 7==ci.lCol) /* || (0==ci.lRow && 8==ci.lCol)*/)))
		{
			p.occurrences += ci.penaltyMultiplier;
			if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
	}	}
}

void QFunc(ComboInfo &ci, Penalty &p){
	if (   sameHand(ci.cCol, ci.lCol)
		/*&& (0==ci.cRow || 0==ci.lRow)
		&& (0==ci.lCol || 9==ci.lCol || 0==ci.cCol || 9==ci.cCol)*/
		)
	{

		//QS, QD, QF, QG
		if (0==ci.lCol && 0==ci.lRow){ //Q
			if( 1==ci.cRow  &&  ( ci.cCol>=1 && ci.cCol<=4 ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//SQ, DQ, FQ, GQ
		}else if (0==ci.cCol && 0==ci.cRow){ //Q
			if( 1==ci.lRow  &&  ( ci.lCol>=1 && ci.lCol<=4 ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}
		//PJ, PK, PL, PH
		}else if (9==ci.lCol && 0==ci.lRow){ //Q
			if( 1==ci.cRow  &&  ( ci.cCol>=5 && ci.cCol<=8 ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}
		//JP, KP, LP, HP
		}else if (9==ci.cCol && 0==ci.cRow){ //Q
			if( 1==ci.lRow  &&  ( ci.lCol>=5 && ci.lCol<=8 ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}
		}
	}
}
void RFunc(ComboInfo &ci, Penalty &p){
	if (sameHand(ci.cCol, ci.lCol)){
		//DR, DT
		if (1==ci.lRow && 2==ci.lCol){
			if( 0==ci.cRow  &&  (3==ci.cCol || 4==ci.cCol) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//RD, TD
		}else if (1==ci.cRow && 2==ci.cCol){
			if( 0==ci.lRow  &&  (3==ci.lCol || 4==ci.lCol) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//KU, KY
		}else if (1==ci.lRow && 7==ci.lCol){
			if( 0==ci.cRow  &&  (5==ci.cCol || 6==ci.cCol) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//UK, YK
		}else if (1==ci.cRow && 7==ci.cCol){
			if( 0==ci.lRow  &&  (5==ci.lCol || 6==ci.lCol) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		}
	}
}
void XFunc(ComboInfo &ci, Penalty &p){
	if (sameHand(ci.cCol, ci.lCol)){
		//XA XD XF XG
		if ( 2==ci.lRow && 1==ci.lCol ){
			if( 1==ci.cRow  &&  ( 0==ci.cCol || 2==ci.cCol || 3==ci.cCol ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//AX DX FX GX
		}else if (2==ci.cRow && 1==ci.cCol){
			if( 1==ci.lRow  &&  ( 0==ci.lCol || 2==ci.lCol || 3==ci.lCol )){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//.; .K .J .H
		}else if (2==ci.lRow && 8==ci.lCol){
			if( 1==ci.cRow  &&  ( 6==ci.cCol || 7==ci.cCol || 9==ci.cCol ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//;. K. J. H.
		}else if (2==ci.cRow && 8==ci.cCol){
			if( 1==ci.lRow  &&  ( 6==ci.lCol || 7==ci.lCol || 9==ci.lCol ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		}
	}
}

void CFunc(ComboInfo &ci, Penalty &p){
	if (sameHand(ci.cCol, ci.lCol)){
		//CA CS CF CG
		if ( 2==ci.lRow && 2==ci.lCol ){
			if( 1==ci.cRow  &&  ( 0==ci.cCol || 1==ci.cCol || 3==ci.cCol || 4==ci.cCol ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//AC SC FC GC
		}else if (2==ci.cRow && 2==ci.cCol){
			if( 1==ci.lRow  &&  ( 0==ci.lCol || 1==ci.lCol || 3==ci.lCol || 4==ci.lCol ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}	
		//,J ,K ,; ,H
		}else if (2==ci.lRow && 7==ci.lCol){
			if( 1==ci.cRow  &&  ( 5==ci.cCol || 6==ci.cCol || 8==ci.cCol || 9==ci.cCol ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		//J, K, ;, H,
		}else if (2==ci.cRow && 7==ci.cCol){
			if( 1==ci.lRow  &&  ( 5==ci.lCol || 6==ci.lCol || 8==ci.lCol || 9==ci.lCol ) ){
				p.occurrences += ci.penaltyMultiplier;
				if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
			}		
		}
	}
}

//ROLLING BONUS
void rollingBonusFunc(ComboInfo &ci, Penalty &p)
{
	if (sameHand(ci.cCol, ci.lCol)){ //same hand
		if (ci.cRow == ci.lRow){	//same row
			if ( abs(ci.cCol - ci.lCol) == 1 ){	//if adjacent cols
				if ( ci.cCol!=4 && ci.lCol!=4 && ci.cCol!=5 && ci.lCol!=5 ){ //not the middle col
					p.occurrences += ci.penaltyMultiplier;
					if (ci.lastChrWasSpace)p.spacekeyReductions += ci.penaltyMultiplier;
				}
			}
		}
	}
}
