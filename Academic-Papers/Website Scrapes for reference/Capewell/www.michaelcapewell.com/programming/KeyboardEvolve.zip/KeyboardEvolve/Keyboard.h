/*==============================================================================
Keyboard.h                                                            Keyboard.h
================================================================================

Created: 2005/05/29 (May 29, 2005)
Author : Michael Capewell (smozoma@yahoo.com)

This is an object representing one keyboard layout.

It can generate a random layout, a layout from a file, 
or a standard layout built into it (see Keyboard::setLayout(int)).

It can calculate and store the score for the layout.

Keys are constrained to have the same shift state as with QWERTY (quote must be
above apostrophe, etc).
==============================================================================*/

/*
TODO:1000:
* instead of hardcoding the layouts (QWERTY, etc) in here, use an INI file
*/

#include <string>
#include <vector>

#include "Score.h"

struct combo{
	std::string chars;
	unsigned int weight;
};

class Keyboard {

public:

	//keyboard identifier constants
	int const static ROWS = 3;
	int const static KEYSPERROW = 10;

	const int static l_NUMSTANDARDLAYOUTS = 7; //qwerty to arensito
	const int static l_QWERTY = 0;
	const int static l_DVORAK = 1;
	const int static l_CAPEWELLSHOLES = 2;
	const int static l_CAPEWELLDVORAK = 3;
	const int static l_KLAUSLER2 = 4;
	const int static l_ARENSITO = 5;
	const int static l_TEST = 6;
	const int static l_RANDOM = 7;

	const int static TEST_METHOD_TEXT = Score::TEST_METHOD_TEXT;
	const int static TEST_METHOD_COMBOS = Score::TEST_METHOD_COMBOS;

	Keyboard();
	Keyboard(int layoutID);
	Keyboard(std::string name, std::string layout);
	~Keyboard();

	void setLayout(int layoutID);
	void setName(std::string newName);
	void mutateLayout();

	static void setTestMethod(int testMethodConst);
	static int getTestMethod();
	static std::string::size_type setTextToTest(std::string textToTest);
	static std::vector<combo>::size_type setCombosToTest(std::vector<combo> combosToTest);

	int calculateScore();	//static void setTestMethod(int) must be called first

	const std::string getLayout();
	const std::string getName();
	const int getScore() const;
	const bool equivalent(Keyboard &aKeyboard); //Sees if the layouts are the same (but 
												 //can have dif names)
	static const unsigned int getNumKeyboardsChecked();

	const void printKeyboard();
	const std::string toString();
	const std::string getLayoutStr();
	std::string scoreSummary();

	friend bool operator<(const Keyboard &lhs, const Keyboard &rhs){
		return lhs.getScore() < rhs.getScore();
		//return lhs.m_score.getTotalScore() < rhs.m_score.getTotalScore();
	}

private: 

	static unsigned int m_NumKeyboardsChecked;

	std::string m_name;
	Score m_score;
	char m_layout[Keyboard::ROWS][Keyboard::KEYSPERROW];
	int  m_lookupTable[(int)'Z'+1][3];

	static int m_TestMethod;
	static std::string m_TextToTest;
	static std::vector<combo> m_combosToTest;		
	//static std::vector<unsigned int> m_comboWeights;
	static bool comboShouldNotBeRemoved(const combo &aCombo);

	void getRandomLayout();
	std::string getTestLayout();

};
