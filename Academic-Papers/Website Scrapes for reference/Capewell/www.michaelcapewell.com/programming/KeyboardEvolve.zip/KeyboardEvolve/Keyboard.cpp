/*==============================================================================
Keyboard.cpp                                                        Keyboard.cpp
================================================================================

Created: 2005/05/29 (May 29, 2005)
Author : Michael Capewell (smozoma@yahoo.com)

This is an object representing one keyboard layout.

It can generate a random layout, a layout from a file (not yet implemented), 
or a standard layout built into it (see Keyboard::setLayout(int)).

It can calculate and store the score for the layout.

Keys are constrained to have the same shift state as with QWERTY (quote must be
above apostrophe, etc).  You could change that if you wanted to, in "fixChar"
and "fixLastChar"
==============================================================================*/

/*
TODO:100:
*   calculateScore needs some cleaning up after being torn apart for the Score class
        and the addition of the combo method of scoring
*   get rid of hard-coded layouts.  use an INI file instead.
*   rename some things with misleading names
*   get rid of the inconsistensices between m_layoutStr, m_layout, and m_lookupTable
*/

#include "Keyboard.h"
#include "stringmanip.h"

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <fstream>
#include <algorithm>

using namespace std;
/*using std::cout;		using std::string;
using std::vector;*/

string Keyboard::m_TextToTest = "";
int Keyboard::m_TestMethod = 0;
unsigned int Keyboard::m_NumKeyboardsChecked = 0;
vector<combo> Keyboard::m_combosToTest;
//vector<unsigned int> Keyboard::m_comboWeights;

string layoutStr;
const static char allKeys[Keyboard::ROWS*Keyboard::KEYSPERROW+1] 
		= "ABCDEFGHIJ"
		  "KLMNOPQRST"
		  "UVWXYZ',.;";

void fixChr(char &chr, bool &shifted);
void fixLastChr(char &lastChr);

/*==============================================================================
Constructors, Destructors, and init          Constructors, Destructors, and init
==============================================================================*/
Keyboard::Keyboard() : m_name(""){
	//init();
}

Keyboard::Keyboard(int layoutID) {
	//init();
	setLayout(layoutID);
}

Keyboard::Keyboard(std::string name, std::string layout){
	m_score.reset();
	m_name = name;
	layoutStr = layout;
	//copy the temporary layout string into the layout array
	for(int i=0; i<ROWS; i++){
		for(int j=0; j<KEYSPERROW; j++){
			m_layout[i][j] = layoutStr.at(10*i+j);
		}
	}

	//first, put the keys and key locations in a look-up table. 
	//(This is way faster than iterating through the layout array)
	//int m_lookupTable[(int)'Z'+1][3]; //'Z' is the highest char we'll look at
	memset(m_lookupTable, -1, ((int)'Z'+1)*3*sizeof(int));
	for (int i = 0; i < ROWS; i++){
		for (int j = 0; j < KEYSPERROW; j++){
			m_lookupTable[ (int)m_layout[i][j] ][ 0 ] = (int)m_layout[i][j];
			m_lookupTable[ (int)m_layout[i][j] ][ 1 ] = i;
			m_lookupTable[ (int)m_layout[i][j] ][ 2 ] = j;
		}
	}
}

Keyboard::~Keyboard() {
}

/*==============================================================================
setLayout															   setLayout
================================================================================
INPUT : int layoutID      : indicates which layout we want to use 
                            (including random and from a file)
OUTPUT: int    layout[][] : contains the layout to use
	    string layoutStr  : contains the layout to use (we don't use this, it
		                    was just easier to do it this way -- less typing).
		uint score        : resets the score to zero.

==============================================================================*/
void Keyboard::setLayout(int layoutID){

	m_score.reset();

	switch (layoutID){
		case l_QWERTY: 
			m_name = "QWERTY";
			layoutStr = "QWERTYUIOP" "ASDFGHJKL;" "ZXCVBNM,.'";
			break;
		case l_DVORAK: 
			m_name = "Dvorak";
			layoutStr = "',.PYFGCRL" "AOEUIDHTNS" ";QJKXBMWVZ";
			break;
		case l_CAPEWELLSHOLES:
			m_name = "Capewell-QWERTY";
			layoutStr = "QWDRFJYPLK" "ASETGHUIO," "ZXCVBNM;.'";
			break;
		case l_CAPEWELLDVORAK: 
			m_name = "Capewell-Dvorak";
			layoutStr = "',.PYQFGRK" "OAEIUDHTNS" "ZXCVJLMWB;";
			break;
		case l_KLAUSLER2: 
			m_name = "Klausler2";
			layoutStr = "K,UYPWLMFC" "OAEIDRNTHS" "Q.';ZXVGBJ";
			break;
		case l_ARENSITO: 
			m_name = "Arensito";
			layoutStr = "QL,P';FUDK" "ARENBGSITO" "ZW.HJVCYMX";
			break;
		case l_TEST: 
			layoutStr = getTestLayout();
			break;
		case l_RANDOM: 
			m_name = "random";
			getRandomLayout();
			break;
	}//switch layoutID

	//copy the temporary layout string into the layout array
	if (layoutID != l_RANDOM){
		for(int i=0; i<ROWS; i++){
			for(int j=0; j<KEYSPERROW; j++){
				m_layout[i][j] = layoutStr.at(10*i+j);
	}	}	}

	//first, put the keys and key locations in a look-up table. 
	//(This is way faster than iterating through the layout array)
	//int m_lookupTable[(int)'Z'+1][3]; //'Z' is the highest char we'll look at
	memset(m_lookupTable, -1, ((int)'Z'+1)*3*sizeof(int));
	for (int i = 0; i < ROWS; i++){
		for (int j = 0; j < KEYSPERROW; j++){
			m_lookupTable[ (int)m_layout[i][j] ][ 0 ] = (int)m_layout[i][j];
			m_lookupTable[ (int)m_layout[i][j] ][ 1 ] = i;
			m_lookupTable[ (int)m_layout[i][j] ][ 2 ] = j;
		}
	}


 }//setLayout

const string Keyboard::getLayout(){
	return layoutStr;
}


/*==============================================================================
equivalent											                  equivalent
================================================================================
INPUT : a Keyboard
RETURN: bool indicating if this keyboard's layout 
	    and the input keyboard's layout are the same
==============================================================================*/
bool const Keyboard::equivalent(Keyboard &aKeyboard){

	for (int i = 0; i<ROWS; i++){
		for (int j = 0; j<KEYSPERROW; j++){
			if (aKeyboard.m_layout[i][j] != m_layout[i][j]){
				return false;//not equivalent
	}	}	}

	return true;//equivalent

}
/*==============================================================================
printKeyboard											           printKeyboard
================================================================================
INPUT : none
OUTPUT: outputs the layout to the screen, 3x10 characters
==============================================================================*/
const void Keyboard::printKeyboard(){

	cout << m_name << "\n";
	cout << "score: " << m_score.getTotalScore() << "\n";
	for(int i=0; i<ROWS; i++){
		for(int j=0; j<KEYSPERROW; j++){
			cout << m_layout[i][j];
		}
		cout << "\n";
	}
	cout << "\n";	//space
}

/*==============================================================================
toString											                    toString
================================================================================
INPUT : none
RETURN: string representing the keyboard (including name, score, and layout)
==============================================================================*/
string const Keyboard::toString(){

	std::stringstream str;

	str << "Name: \t"
		<< m_name
		<< "\n"
		<< "Score: \t"
		<< to_string<int>(m_score.getTotalScore(), std::dec)
		<< "\n";

	str << "Layout:";
	for(int i=0; i<ROWS; i++){
		str << "\t";
		for(int j=0; j<KEYSPERROW; j++){
			str << m_layout[i][j];
		}
		str << "\n";
	}

	return str.str();
}
/*==============================================================================
getLayoutStr											            getLayoutStr
================================================================================
INPUT : none
RETURN: string representing the keyboard layout
==============================================================================*/
string const Keyboard::getLayoutStr()
{
	std::stringstream str;

	for(int i=0; i<ROWS; i++){
		for(int j=0; j<KEYSPERROW; j++){
			str << m_layout[i][j];
		}
	}

	return str.str();
}

/*==============================================================================
getRandomLayout											         getRandomLayout
================================================================================
INPUT : none
RETURN: string : contains the layout to use
==============================================================================*/
string Keyboard::getTestLayout(){

	string strLayout;
	string line;

	std::ifstream in("testlayout.txt");
	getline(in, line);
	if ('\r' == line[line.size()-1]) line.erase(line.size()-1);
	m_name = line;
	while(getline(in, line)){
		if ('\r' == line[line.size()-1]) line.erase(line.size()-1);
		strLayout  += line + "\n";
	}
	in.close();
	return strLayout;

}

/*==============================================================================
getRandomLayout											         getRandomLayout
================================================================================
INPUT : none
OUTPUT: char *m_layout : contains the layout to use
==============================================================================*/
void Keyboard::getRandomLayout(){

	int rnd;
	rand(); //it keeps giving the same first letter, unless i do this first.

	//we randomly look at places in keysleft to grab characters for the layout.
	//when we use a character, we then set that position to zero.
	char keysLeft[ROWS*KEYSPERROW];
	
	memcpy(keysLeft, allKeys, ROWS*KEYSPERROW);
	memset(m_layout, NULL, ROWS*KEYSPERROW);


	//I'm often changing my pre-set keys, so this part gets messy:
	//--------------------------------------------------------------------------

	//E on right side, not pinky or bottom row
	int rndRow;
	/*do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		rndRow = int(2.0 * rand()/(RAND_MAX+1.0));
		if (rnd<=5 || 9==rnd || 2==rndRow)  continue; //try again not on right hand or if pinky
		if (NULL == m_layout[rndRow][rnd])  m_layout[rndRow][rnd] = 'E';
	}while(m_layout[rndRow][rnd] != 'E');
	keysLeft['E'-'A'] = NULL;*/

/*	//E on left side, not pinky or bottom row
	int rndRow;
	do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		rndRow = int(2.0 * rand()/(RAND_MAX+1.0));
		if (rnd>=4 || 0==rnd || 2==rndRow)  continue; //try again not on left hand or if pinky
		if (NULL == m_layout[rndRow][rnd])  m_layout[rndRow][rnd] = 'E';
	}while(m_layout[rndRow][rnd] != 'E');
	keysLeft['E'-'A'] = NULL;
*/

/*
	//E is ALWAYS in [1][2]
	//m_layout[1][2] = 'E';
	//place TOAIN on the home row keys (and not the middle keys).
	//these are the next 5 most used keys, by far.
	{
	//E on left side, not pinky
	do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		if (rnd>=4 || 0==rnd)  continue; //try again not on left hand or if pinky
		if (NULL == m_layout[1][rnd])  m_layout[1][rnd] = 'E';
	}while(m_layout[1][rnd] != 'E');
	//TOAIN on home row
	do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		if (4==rnd || 5==rnd)  continue; //these keys would require reaching
		if (NULL == m_layout[1][rnd])  m_layout[1][rnd] = 'T';
	}while(m_layout[1][rnd] != 'T');
	do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		if (4==rnd || 5==rnd)  continue;
		if (NULL == m_layout[1][rnd])  m_layout[1][rnd] = 'O';
	}while(m_layout[1][rnd] != 'O');
	do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		if (4==rnd || 5==rnd)  continue;
		if (NULL == m_layout[1][rnd])  m_layout[1][rnd] = 'A';
	}while(m_layout[1][rnd] != 'A');
	do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		if (4==rnd || 5==rnd)          continue;//these keys would require reaching
		if (NULL == m_layout[1][rnd])  m_layout[1][rnd] = 'I';
	}while(m_layout[1][rnd] != 'I');
	do{
		rnd = int(10.0 * rand()/(RAND_MAX+1.0));
		if (4==rnd || 5==rnd)  continue;
		if (NULL == m_layout[1][rnd])  m_layout[1][rnd] = 'N';
	}while(m_layout[1][rnd] != 'N');
			//do{
			//	rnd = int(10.0 * rand()/(RAND_MAX+1.0));
			//	if (4==rnd || 5==rnd)continue;
			//	if (NULL == m_layout[1][rnd])
			//		m_layout[1][rnd] = 'S';
			//}while(m_layout[1][rnd] != 'S');
			//do{
			//	rnd = int(10.0 * rand()/(RAND_MAX+1.0));
			//	if (4==rnd || 5==rnd)continue;
			//	if (NULL == m_layout[1][rnd])
			//		m_layout[1][rnd] = 'R';
			//}while(m_layout[1][rnd] != 'R');
	keysLeft['E'-'A'] = NULL;
	keysLeft['T'-'A'] = NULL;
	keysLeft['O'-'A'] = NULL;
	keysLeft['A'-'A'] = NULL;
	keysLeft['I'-'A'] = NULL;
	keysLeft['N'-'A'] = NULL;
			//keysLeft['S'-'A'] = NULL;
			//keysLeft['R'-'A'] = NULL;
	}//placed ETOAINSR on the home row keys (and not the middle keys).
*/
	//place ZCXV on the bottom row, [2][0 to 3]
	{
	do{
		rnd = int(4.0 * rand()/(RAND_MAX+1.0));
		if (NULL == m_layout[2][rnd])  m_layout[2][rnd] = 'Z';
	}while(m_layout[2][rnd] != 'Z');
	do{
		rnd = int(4.0 * rand()/(RAND_MAX+1.0));
		if (NULL == m_layout[2][rnd])  m_layout[2][rnd] = 'X';
	}while(m_layout[2][rnd] != 'X');
	do{
		rnd = int(4.0 * rand()/(RAND_MAX+1.0));
		if (NULL == m_layout[2][rnd])  m_layout[2][rnd] = 'C';
	}while(m_layout[2][rnd] != 'C');
	do{
		rnd = int(4.0 * rand()/(RAND_MAX+1.0));
		if (NULL == m_layout[2][rnd])  m_layout[2][rnd] = 'V';
	}while(m_layout[2][rnd] != 'V');
	keysLeft['C'-'A'] = NULL; //C
	keysLeft['V'-'A'] = NULL; //V
	keysLeft['X'-'A'] = NULL; //X
	keysLeft['Z'-'A'] = NULL; //Z
	}//placed ZCXV on the bottom row [2][0 to 3]

	layoutStr="";
	bool doneThisKey = false;
	//go over each layout position and put a key in it
	for(int i=0; i<ROWS; i++){
		for(int j=0; j<KEYSPERROW; j++){
			if (NULL != m_layout[i][j]){ 
				continue; //A pre-placed key is already here.
			}
			doneThisKey = false;
			while(!doneThisKey){
				rnd = int(30.0 * rand()/(RAND_MAX+1.0));
				if (NULL != keysLeft[rnd]){

					m_layout[i][j] = keysLeft[rnd];
					keysLeft[rnd] = NULL;
					doneThisKey = true;

				}//if !NULL
			}//while !doneThisKey
		}//for i
	}//for j
}//getRandomLayout

/*==============================================================================
mutateLayout											            mutateLayout
================================================================================
INPUT : none
OUTPUT: char layout  : contains the new, mutated, layout
        note that layoutStr has not changed!
==============================================================================*/
void Keyboard::mutateLayout(){

	int src, dst;
	register int srcRow, srcCol, dstRow, dstCol;
	char temp;
	bool tryAgain;

	m_score.reset();

	//use these to compare the new layout with the old layout at the end
	Keyboard oldkb = *this;
	Keyboard newkb;

	//after each mutation, there is a 50% chance of doing another mutation
	do{//while(rand() > RAND_MAX/2.0);

		tryAgain = false;

		src = int(30.0 * rand()/(RAND_MAX+1.0));
		do{
			dst = int(30.0 * rand()/(RAND_MAX+1.0));
		}while (dst == src);

		srcRow = (src-(src%10))/10;
		srcCol = src%10;
		dstRow = (dst-(dst%10))/10;
		dstCol = dst%10;


		//I'm often changing my pre-set keys, so this part gets messy:
		//----------------------------------------------------------------------
		//disallow certain undesirable mutations (while allowing for their reverse)

		//disallowing certain mutations will increase the efficiency
		//of the program (so it's not taking the time to check obviously-bad layouts)

		//don't let E be mutated away from [1][2] (if it's already there)
		//if (2==srcCol){
		//	if ('E' == m_layout[srcRow][srcCol])  continue;//generate new src and dst
		//}else if (2==dstCol){
		//	if ('E' == m_layout[dstRow][dstCol])  continue;//generate new src and dst
		//}

		//don't let E be mutated off the right hand, into the pinky position, or into the bottom row
		if ( (2!=srcRow  /*&&  (srcCol>=6 && srcCol<=8)*/)  //if it's the source, don't move it
				&& (2==dstRow /*|| dstCol<=5*/ || 9==dstCol || 0==dstCol) ){
			if (       'E' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}else if ( (2!=dstRow  /*&&  (dstCol>=6 && dstCol<=8)*/)  //if it's the destination, don't move it
				&& (2==srcRow /*|| srcCol<=5 */ || 9==srcCol || 0==srcCol ) ){
			if (       'E' == m_layout[dstRow][dstCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}

		/*//don't let E be mutated off the left hand, into the pinky position, or into the bottom row
		if ( (2!=srcRow  &&  (srcCol<=3 && srcCol>=1))  //if it's the source, don't move it
				&& (2==dstRow || dstCol>=4 || 0==dstCol) ){
			if (       'E' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}else if ( (2!=dstRow  &&  (dstCol<=3 && dstCol>=1))  //if it's the destination, don't move it
				&& (2==srcRow || srcCol>=4 || 0==srcCol ) ){
			if (       'E' == m_layout[dstRow][dstCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}*/
		//don't let ETOAIN be mutated to a centre column
		if ( (srcCol<=3 || srcCol>=6)  //if it's the source, don't move it
				&& (dstCol>=4 && dstCol<=5) ){
			if (       'T' == m_layout[srcRow][srcCol] || 'O' == m_layout[srcRow][srcCol]
			        || 'A' == m_layout[srcRow][srcCol] || 'I' == m_layout[srcRow][srcCol]
					|| 'N' == m_layout[srcRow][srcCol] || 'E' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}else if ( (dstCol<=3 || dstCol>=6)  //if it's the destination, don't move it
				&& (srcCol>=4 && srcCol<=5) ){
			if (       'T' == m_layout[dstRow][dstCol] || 'O' == m_layout[dstRow][dstCol] 
			        || 'A' == m_layout[dstRow][dstCol] || 'I' == m_layout[dstRow][dstCol]
					|| 'N' == m_layout[srcRow][srcCol] || 'E' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}
/*
		//don't let E be mutated off the left hand or into the pinky position
		if ( (1==srcRow  &&  (srcCol<=3 && srcCol>=1))  //if it's the source, don't move it
				&& (1!=dstRow || dstCol>=4 || 0==dstCol) ){
			if (       'E' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}else if ( (1==dstRow  &&  (dstCol<=3 && dstCol>=1))  //if it's the destination, don't move it
				&& (1!=srcRow || srcCol>=4 || 0==srcCol ) ){
			if (       'E' == m_layout[dstRow][dstCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}

		//don't let TOAIN be mutated off the home keys
		if ( (1==srcRow  &&  (srcCol<=3 || srcCol>=6))  //if it's the source, don't move it
				&& (1!=dstRow || (dstCol>=4 && dstCol<=5) ) ){
			if (       'T' == m_layout[srcRow][srcCol] || 'O' == m_layout[srcRow][srcCol]
			        || 'A' == m_layout[srcRow][srcCol] || 'I' == m_layout[srcRow][srcCol]
					|| 'N' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}else if ( (1==dstRow  &&  (dstCol<=3 || dstCol>=6))  //if it's the destination, don't move it
				&& (1!=srcRow || (srcCol>=4 && srcCol<=5) ) ){
			if (       'T' == m_layout[dstRow][dstCol] || 'O' == m_layout[dstRow][dstCol] 
			        || 'A' == m_layout[dstRow][dstCol] || 'I' == m_layout[dstRow][dstCol]
					|| 'N' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}
*/
		//don't let ZXCV be mutated out of [2][0 to 3]
		if ( (2==srcRow  &&  srcCol<=3)				// if src == ZXCV
				&&  ( 2!=dstRow  ||  dstCol>=3) ){  //    and dst != ZXCV
			if (       'Z' == m_layout[srcRow][srcCol] || 'X' == m_layout[srcRow][srcCol]
					|| 'C' == m_layout[srcRow][srcCol] || 'V' == m_layout[srcRow][srcCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}else if ( (2==dstRow  &&  dstCol<=3)		// if dst == ZXCV
				&&  ( 2!=srcRow  ||  srcCol>=3) ){  //    and src != ZXCV
			if (       'Z' == m_layout[dstRow][dstCol] || 'X' == m_layout[dstRow][dstCol]
					|| 'C' == m_layout[dstRow][dstCol] || 'V' == m_layout[dstRow][dstCol]){
				tryAgain = true; //generate new src and dst
				continue;
			}
		}

				//don't let ZXCV be mutated off the bottom row
				//if ( 2==srcRow  &&  2!=dstRow ){//if it's the source, don't move it
				//	if (       'Z' == m_layout[srcRow][srcCol] || 'X' == m_layout[srcRow][srcCol]
				//	        || 'C' == m_layout[srcRow][srcCol] || 'V' == m_layout[srcRow][srcCol])
				//		continue; //generate new src and dst
				//}else if ( 2==dstRow  &&  2!=srcRow ){ //if it's the destination, don't move it
				//	if (       'Z' == m_layout[dstRow][dstCol] || 'X' == m_layout[dstRow][dstCol]
				//	        || 'C' == m_layout[dstRow][dstCol] || 'V' == m_layout[dstRow][dstCol])
				//		continue; //generate new src and dst
				//}

		//----------------------------------------------------------------------
		//do the actual mutation!
		temp                         = m_layout[ dstRow ][ dstCol ];
		m_layout[ dstRow ][ dstCol ] = m_layout[ srcRow ][ srcCol ];
		m_layout[ srcRow ][ srcCol ] = temp;
		//update the lookup table
		m_lookupTable[ (int)m_layout[srcRow][srcCol] ][ 1 ] = srcRow;
		m_lookupTable[ (int)m_layout[srcRow][srcCol] ][ 2 ] = srcCol;
		m_lookupTable[ (int)m_layout[dstRow][dstCol] ][ 1 ] = dstRow;
		m_lookupTable[ (int)m_layout[dstRow][dstCol] ][ 2 ] = dstCol;

		newkb = *this;

	}while(newkb.equivalent(oldkb) || tryAgain || (rand() > RAND_MAX/2) );//50% chance of doing another mutation

}//mutateLayout

/*==============================================================================
getName											                         getName
==============================================================================*/
const string Keyboard::getName(){
	return m_name;
}
/*==============================================================================
setName											                         setName
==============================================================================*/
void Keyboard::setName(string newName){
	m_name = newName;
}

/*==============================================================================
getNumKeyboardsChecked								     gettNumKeyboardsChecked
==============================================================================*/
const unsigned int Keyboard::getNumKeyboardsChecked(){
	return Keyboard::m_NumKeyboardsChecked;
}

/*==============================================================================
getScore											                    getScore
==============================================================================*/
const int Keyboard::getScore() const {
	return m_score.getTotalScore();
}

/*==============================================================================
setTestMethod											           setTestMethod
================================================================================
INPUT : int testMethodConst (TEST_METHOD_TEXT or TEST_METHOD_COMBOS)
==============================================================================*/
void Keyboard::setTestMethod(int testMethodConst){
	Keyboard::m_TestMethod = testMethodConst;
}
/*==============================================================================
getTestMethod											           getTestMethod
================================================================================
INPUT : (none)
OUTPUT: int m_TestMethod (TEST_METHOD_TEXT or TEST_METHOD_COMBOS)
==============================================================================*/
int Keyboard::getTestMethod(){
	return m_TestMethod;
}

/*==============================================================================
setTextToTest											           setTextToTest
================================================================================
==============================================================================*/
string::size_type Keyboard::setTextToTest(string textToTest){
	Keyboard::m_TextToTest = textToTest;
	return Keyboard::m_TextToTest.length();
}

/*==============================================================================
setCombosToTest											         setCombosToTest
================================================================================
INPUT : vector<combo>       &combosToTest
RETURN: the number of combos (ignoring weighting)
SIDE EFFECTS: removes certain combos that wouldn't be used in scoring
==============================================================================*/
vector<combo>::size_type Keyboard::setCombosToTest(vector<combo> combosToTest){
	
	//TODO:100:  replace parallel vectors with a vector of Combo class
	m_combosToTest = combosToTest;


	//cout << "verifying combos";

	vector<combo>::iterator iter = 
		stable_partition(m_combosToTest.begin(), m_combosToTest.end(), comboShouldNotBeRemoved);
	m_combosToTest.erase(iter, m_combosToTest.end());

	/*
	int count = 0;

	

	do{

		++count;
		if (count%256 == 0) cout << ".";

		if (comboShouldBeRemoved(*iter)){

			iter = m_combosToTest.erase(iter);

		}else{//don't remove
			++iter;
		}

	}while(iter != m_combosToTest.end());*/

	//cout << " done! " << "\n";

	return m_combosToTest.size();


	/*std::ofstream outfile;
	outfile.open("z_cleanedcombolist.txt");
	for (unsigned int i = 0; i < m_combosToTest.size(); i++){
		outfile << m_combosToTest[i] << "\n";
		outfile << m_comboWeights[i] << "\n";
	}
	outfile.close();*/

}

/*==============================================================================
comboShouldNotBeRemoved								  	 comboShouldNotBeRemoved
================================================================================
//eliminate combos that are not one of: 
//			2 characters with no spaces
//			2 characters not the same
//			2 characters + 1 space in the middle (boundary between words)
//          1 character  + 2 leading spaces (boundary at start of sentence)
==============================================================================*/

inline
bool Keyboard::comboShouldNotBeRemoved(const combo &aCombo){
	
	if (aCombo.chars.length() == 2){
		//eliminate those WITH a space
		//eliminate those with duplicate chars
		if ( aCombo.chars.find(" ", 0) != string::npos ){
			return false;
		}else if (aCombo.chars.at(0) == aCombo.chars.at(1)){
			return false;
		}
	}else if(aCombo.chars.length() == 3){
		//eliminate those WITHOUT a space in the MIDDLE
		//eliminate those WITH a space at the END
		if ( aCombo.chars.find(" ", 1) != 1){
			return false;
		}else if (aCombo.chars.find(" ", 2) == 2 ){
			return false;
		}
	}else{ //eliminate those with length not 2 or 3
		return false;
	}

	return true;
}

/*==============================================================================
calculateScore											          calculateScore
================================================================================
INPUT : string textToTest
OUTPUT: uint score

//TODO:100: needs some cleaning up after being torn apart for the Score class
==============================================================================*/
int Keyboard::calculateScore(){

	++m_NumKeyboardsChecked;

	register char chr = -1;
	char lastChr = -1;

	ComboInfo ci;	/*struct ComboInfo{
						int cRow;				//current letter row
						int cCol;				//current letter column
						bool shifted;			//used to indicate if we're using a shifted punctuation 
												//mark: " < > :
						int lRow;				//last(previous) letter row
						int lCol;				//last(previous) letter column
						bool lastChrWasSpace;	//used to reduce some penalties
						unsigned int penaltyMultiplier;
					};*/

	ci.lastChrWasSpace = false;

    //--------------------------------------------------------------------------
	//iterating through all the characters in the text or all the combos

	if  (TEST_METHOD_TEXT == m_TestMethod){

		std::string::const_iterator iter = m_TextToTest.begin();
		ci.penaltyMultiplier = 1;

		for(std::string::const_iterator iter = m_TextToTest.begin(); 
			iter != m_TextToTest.end();
			++iter){

			if (false == ci.lastChrWasSpace){

				ci.lRow = ci.cRow;
				ci.lCol = ci.cCol;
				lastChr = chr;

				chr = toupper(*iter);	//the letter
				if (chr == lastChr)  continue;		//nevermind hitting the same key twice
				ci.cRow = -1; //current letter row
				ci.cCol = -1; //current letter column

				if (' ' == chr || '\r' == chr || '\n' == chr){
					ci.lastChrWasSpace = true;	//we use this to reduce penalties
					continue;
				}

				if (chr > 'Z' || chr < 0 )  continue;	//anything above Z will not be in the layout.
														//if we allow chr > 'Z' we will look outside 
														//of m_lookupTable!  KABOOM!

				fixChr(chr, ci.shifted); // change "<" to "," etc and set 'ci.shifted'

				//----------------------------------------------------------------------------
				//finding the location of the character on the keyboard

				//find the current Row and current Col
				if ((int)chr == m_lookupTable[(int)chr][0]){
					ci.cRow = m_lookupTable[ (int)chr ][ 1 ];
					ci.cCol = m_lookupTable[ (int)chr ][ 2 ];
				}

				//if we couldn't find the character, 
				if (chr != m_layout[ci.cRow][ci.cCol]){
					ci.lRow = -1;  //then reset the lastPos and get the next character.  
					ci.lCol = -1;
					continue; 
				}

			}else{ //true == ci.lastChrWasSpace

				chr = toupper(*iter);	//the letter

				if (chr == lastChr){
					ci.cRow = ci.lRow;
					ci.cCol = ci.lCol;
					ci.lastChrWasSpace = false;
					continue;		//nevermind hitting the same key twice
				}


				if (' ' == chr || '\r' == chr || '\n' == chr || chr > 'Z' || chr < 0){
					ci.cRow = -1;
					ci.lRow = -1;
					ci.lCol = -1;
					ci.cCol = -1;
					ci.lastChrWasSpace = false;
					continue;
				}

				fixChr(chr, ci.shifted); // change "<" to "," etc and set 'ci.shifted'

				//----------------------------------------------------------------------------
				//finding the location of the character on the keyboard

				ci.cRow = -1; //current letter row
				ci.cCol = -1; //current letter column
				//find the current Row and current Col
				if ((int)chr == m_lookupTable[(int)chr][0]){
					ci.cRow = m_lookupTable[ (int)chr ][ 1 ];
					ci.cCol = m_lookupTable[ (int)chr ][ 2 ];
				}

				//if we couldn't find the character, 
				if (chr != m_layout[ci.cRow][ci.cCol]){
					ci.lRow = -1;  //then reset the lastPos and get the next character.  
					ci.lCol = -1;
					ci.lastChrWasSpace = false;
					continue; 
				}

			}//if (false == ci.lastChrWasSpace)

			m_score.calculateScore(ci);
			ci.lastChrWasSpace = false;

		}//for iter

	}else if(TEST_METHOD_COMBOS == m_TestMethod){

		for(std::vector<combo>::const_iterator iter = m_combosToTest.begin();
			iter != m_combosToTest.end();
			++iter)
		{	
			ci.penaltyMultiplier = iter->weight;

			if ((*iter).chars.length() == 2){

				/*2 acceptable cases:  both characters are valid
                                       only last character is valid
				*/

				ci.lastChrWasSpace = false;

				chr = toupper(iter->chars[1]);

				if (chr > 'Z' || chr < 0 )  continue;	//anything above Z will not be in the layout.

				fixChr(chr, ci.shifted);

				//find the current Row and current Col
				if ((int)chr == m_lookupTable[(int)chr][0]){
					ci.cRow = m_lookupTable[ (int)chr ][ 1 ];
					ci.cCol = m_lookupTable[ (int)chr ][ 2 ];
				}
 
				//if we couldn't find the character, 
				if (chr != m_layout[ci.cRow][ci.cCol]){
					continue;	//then get the next combo.  
				}

				//do the same for the last char
				lastChr = toupper(iter->chars[0]);
				fixLastChr(lastChr);
				//find the last Row and last Col
				ci.lRow = -1; //if we couldn't find the character, these remain -1
				ci.lCol = -1;
				if ((int)lastChr == m_lookupTable[(int)lastChr][0]){
					ci.lRow = m_lookupTable[ (int)lastChr ][ 1 ];
					ci.lCol = m_lookupTable[ (int)lastChr ][ 2 ];
				}

			}else if (iter->chars.length() == 3){

				/*  Acceptable: "  x" where x is valid
								"y x" where x is valid and y is either valid or invalid
				*/

				//If space only in middle ("y x").  
				//At this point, we are guaranteed there is not a space in x.
				if (' ' != iter->chars[0] && ' ' == iter->chars[1]){

					//ci.lastChrWasSpace = (see end of 'if' block)

					chr = toupper(iter->chars[2]);

					if (chr > 'Z' || chr < 0 )  continue;	//anything above Z will not be in the layout and will crash us

					fixChr(chr, ci.shifted);

					//find the current Row and current Col
					if ((int)chr == m_lookupTable[(int)chr][0]){
						ci.cRow = m_lookupTable[ (int)chr ][ 1 ];
						ci.cCol = m_lookupTable[ (int)chr ][ 2 ];
					}

					//if we couldn't find the character, 
					if (chr != m_layout[ci.cRow][ci.cCol]){
						continue;	//then get the next combo.  
					}

					//do the same for the last char
					lastChr = toupper(iter->chars[0]);
					fixLastChr(lastChr);
					//find the last Row and last Col
					ci.lRow = -1; //if we couldn't find the character, these remain -1
					ci.lCol = -1;
					if ((int)lastChr == m_lookupTable[(int)lastChr][0]){
						ci.lRow = m_lookupTable[ (int)lastChr ][ 1 ];
						ci.lCol = m_lookupTable[ (int)lastChr ][ 2 ];
					}

					if (-1 != ci.lRow){
						ci.lastChrWasSpace = true;
					}else{
						ci.lastChrWasSpace = false;
					}

				}//if 2 leading spaces ("  x")
				else if (' ' == iter->chars[0] && ' ' == iter->chars[1]){

					ci.lastChrWasSpace = false;

					chr = toupper(iter->chars[2]);

					if (chr > 'Z' || chr < 0 )  continue;	//anything above Z will not be in the layout and will crash us

					fixChr(chr, ci.shifted);

					//find the current Row and current Col
					if ((int)chr == m_lookupTable[(int)chr][0]){
						ci.cRow = m_lookupTable[ (int)chr ][ 1 ];
						ci.cCol = m_lookupTable[ (int)chr ][ 2 ];
					}

					//if we couldn't find the character, 
					if (chr != m_layout[ci.cRow][ci.cCol]){
						continue;	//then get the next combo.  
					}

					lastChr = -1;
					ci.lRow = -1;
					ci.lCol = -1;

				}

			}else{
				continue;
			}

			m_score.calculateScore(ci);
			ci.lastChrWasSpace = false;

		}//for iter

	}

	return m_score.getTotalScore();
}

string Keyboard::scoreSummary(){
	return m_score.scoreSummary();
}

inline
void fixChr(char &chr, bool &shifted){
	shifted = false;
	if ('\"' == chr){
		shifted = true;
		chr = '\'';
	}else if('<' == chr){
		shifted = true;
		chr = ',';
	}else if('>' == chr){
		shifted = true;
		chr = '.';
	}else if(':' == chr){
		shifted = true;
		chr = ';';
	}
}

inline
void fixLastChr(char &lastChr){
	if ('\"' == lastChr){
		lastChr = '\'';
	}else if('<' == lastChr){
		lastChr = ',';
	}else if('>' == lastChr){
		lastChr = '.';
	}else if(':' == lastChr){
		lastChr = ';';
	}
}
