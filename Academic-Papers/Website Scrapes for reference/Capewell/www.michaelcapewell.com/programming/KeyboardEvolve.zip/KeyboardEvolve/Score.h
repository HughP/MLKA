/*==============================================================================
Score.h                                                                  Score.h
================================================================================

Created: 2005/06/10 (Jun 10, 2005)
Author : Michael Capewell (smozoma@yahoo.com)

This is a class representing the score for one keyboard layout.

YES IT'S A MESS -- needs refactoring rather badly.  
                   It was a last-minute addition.

==============================================================================*/

#include <string>
#include <vector>

struct ComboInfo{
	int cRow;   //the row    of the 'currently' (most recently) pressed key
	int cCol;   //the column of the 'currently' (most recently) pressed key
	bool shifted;   //indicates that the shift key was used (but only for punctuation marks.  
                    //I.e., if a capital letter was used, shifted will be false, but if any 
                    //of "<>: were used, shift will be true.
	int lRow;   //the row    of the 'last' (previously) pressed key
	int lCol;   //the column of the 'last' (previously) pressed key
	bool lastChrWasSpace;   //true if the space key was pressed between the two keys
	unsigned int penaltyMultiplier;  //how many occurrences of this combo there were.
                                     //E.g., in a test file, the combo TH appeared 2405 times, so penaltyMultiplier=2405
                                     //(i should probably rename this element!)
};
struct Penalty{
	std::string description;		//Description to print
	unsigned int occurrences;		//How many times this penalty was incurred
	int weight;						//How much this penalty costs
	unsigned int spacekeyReductions;//How many times this penalty occurred, but around the space key
	bool inEffect;					//Are we counting this penalty?
	//using a pointer to an array makes it run sloowwww.. 
	void (*penaltyFunc)(ComboInfo &ci, Penalty &p);
};

class Score
{
public:

	const int static TEST_METHOD_TEXT = 0;
	const int static TEST_METHOD_COMBOS = 1;

	Score(void);
	~Score(void);

	void reset();

	void calculateScore(ComboInfo &ci);
	const int getTotalScore() const;

	std::string scoreSummary();

	const std::string scoringParameters();

private:

	std::vector<Penalty> m_penalties;

	void init();

};
