/*==============================================================================
KeyBoardEvolve.cpp                                            KeyBoardEvolve.cpp
================================================================================

Created: 2005/05/29 (May 29, 2005)

Author : Michael Capewell (smozoma@yahoo.com)

"Main" file for running evolutionary framework.

You may want to change some test parameters before running:
Do a search for "THINGS TO SET BEFORE RUNNING" in this file and in Score.cpp
(Eventually, I will eliminate code modifications by allowing the options to be
 set using an INI file)

==============================================================================*/

//TODO:100:  use an INI file instead of requiring recompiling and constants
//TODO:1000: add an estimate of time left (could be tricky)
//TODO:1000: get rid of global scope variables
//TODO:1000: error checking and all that

#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
#include <fstream>
#include <ctime>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <iomanip>

#include <stdexcept>
#include <limits>

using std::vector;		using std::sort;
using std::cout;		using std::cin;
using std::string;

#include "Keyboard.h"
#include "stringmanip.h"


//---- THINGS TO SET BEFORE RUNNING ----//
//int testMethod = Keyboard::TEST_METHOD_TEXT;
static const int testMethodRandom = Keyboard::TEST_METHOD_COMBOS;
static const int testMethodAllStar = Keyboard::TEST_METHOD_COMBOS;
//static const int testMethodAllStar = Keyboard::TEST_METHOD_TEXT;
static const int  RANDOM_SET_SIZE = 512; //should be an even number
static const int  MAX_ALLSTAR_SET_SIZE = 2048; //should be an even number
static const int  STAGNANT_RANDOM_ROUNDS_LIMIT = 16;
static const int  STAGNANT_ALLSTAR_ROUNDS_LIMIT = 512;
static const int  STAGNANT_POOLS_LIMIT = 32;
static const char *TEST_DATA_TEXT_FILE = "testdata_text.txt";
static const char *TEST_DATA_COMBOS_FILE = "testdata_combos.txt";
static const char *LAST_ERA_ALLSTARS_FILE = "z_allstars_last_era.txt";
static const char *LAST_NEW_ALLSTARS_FILE = "z_allstars_last_new.txt";
//------------------------------------//

enum EvolutionMethod{
	EvoNew=1, EvoContinue=2
};

static string getTextToTest(const char *filename);
static vector<combo> getCombosToTest(const char *filename);
//vector<string> getCombosToTest(const char *filename);
//vector<unsigned int> getComboWeights(const char *filename);

void sortAndEliminateDuplicates(vector<Keyboard> &kbs);

static clock_t msRoundStartTime;
static time_t sAnalysisStartTime;
static time_t sAnalysisTotalTime;

Score scoringParameters;

/*==============================================================================
main                                                                        main
================================================================================
==============================================================================*/
int main() {

	scoringParameters.reset(); //TODO:  change the Score class so I don't need 
	                           //       to instantiate a score to call 'scoringParameters()'
	std::ofstream outfile;
	std::ifstream infile;

	sAnalysisStartTime = time(NULL);
	srand((unsigned int)sAnalysisStartTime);

	vector<Keyboard> vRandomLayouts;	//best layouts
	vector<Keyboard> vStandardLayouts;	//scores of the standard layouts
	vector<Keyboard> vAllStarLayouts;	//best layouts from the randoms

	Keyboard::setTextToTest(getTextToTest(TEST_DATA_TEXT_FILE));
	Keyboard::setCombosToTest(getCombosToTest(TEST_DATA_COMBOS_FILE));

	int EvolutionMethodChoice = INT_MAX; //invalid value
	do{//while(EvolutionMethodChoice != EvoNew && EvolutionMethodChoice != EvoContinue)

		cout << "Choose which type of evolution to run:\n"
			<< "1. New\n"
			<< "2. Continue from last era." << std::endl;
		
		if((cin >> EvolutionMethodChoice) && (EvoNew == EvolutionMethodChoice || EvoContinue == EvolutionMethodChoice))
		{
		}else{
			cout << "\nPlease enter an integer number between 1 and 2\n\n";
			cin.clear();
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		}

	}while(EvolutionMethodChoice != EvoNew && EvolutionMethodChoice != EvoContinue);


	//-----------------------------------------------------------------------------
	//standard layouts
	//-----------------------------------------------------------------------------

	//Keyboard kb;

	//create and store the standard layouts 
	Keyboard::setTestMethod(Keyboard::TEST_METHOD_COMBOS);
	for (int i = 0; i < Keyboard::l_NUMSTANDARDLAYOUTS; i++){
		//kb.setLayout(i);
		//kb.calculateScore();
		vStandardLayouts.push_back( Keyboard(i) );
		vStandardLayouts[i].calculateScore();
	}

	sort(vStandardLayouts.begin(), vStandardLayouts.end());

	//print out the standard layouts to screen and to file z_StandardLayouts_combos.txt
	outfile.open("z_standardlayouts.txt");
	outfile << scoringParameters.scoringParameters() << "\n" << "\n";
	for (int i = 0; i < Keyboard::l_NUMSTANDARDLAYOUTS; i++){
		cout << vStandardLayouts[i].toString() << "\n";
		outfile << vStandardLayouts[i].toString() << "\n";
		outfile << vStandardLayouts[i].scoreSummary() << "\n";
	}
	outfile.close();


	unsigned int roundNum = 0;
	int lastRoundsBest;
	unsigned int stagnantRounds;

	if (EvoNew == EvolutionMethodChoice){

		//--------------------------------------------------------------------------
		//random layouts!
		//--------------------------------------------------------------------------
		
		unsigned int poolNum = 0;
		unsigned int stagnantPools = 0;

		int bestPoolYet = INT_MAX;//worst possible score

		Keyboard::setTestMethod(testMethodRandom);

		//each pass through this 'while,' I am calling a 'pool' of keyboards
		while(stagnantPools < STAGNANT_POOLS_LIMIT){ 

			cout << "==================== POOL " << poolNum << " ======================"  << "\n";
			cout << "(" << stagnantPools << "/" << STAGNANT_POOLS_LIMIT << " stagnant)" << "\n";

			lastRoundsBest = UINT_MAX;
			stagnantRounds = 0;

			vRandomLayouts.clear();
			vRandomLayouts.reserve(8*RANDOM_SET_SIZE);

			//initial random set------------------------------------------
			msRoundStartTime = clock(); //time(NULL);

			for (int i = 0; i < 8*RANDOM_SET_SIZE; i++){
				vRandomLayouts.push_back(Keyboard(Keyboard::l_RANDOM));
				vRandomLayouts[i].calculateScore();
			}

			cout << "Time to generate and calculate scores for " 
				<< vRandomLayouts.size() << " layouts: "
				<< ((clock()-msRoundStartTime)/1000.0) << "s" << "\n";

			sortAndEliminateDuplicates(vRandomLayouts);

			vRandomLayouts.resize(RANDOM_SET_SIZE);
			cout << "Pool size culled down to " << RANDOM_SET_SIZE << "\n";

			lastRoundsBest = vRandomLayouts[0].getScore();

			cout << "\n" << "Pool " << poolNum << "'s Best Layout After Random Round:  " << "\n";
			cout << vRandomLayouts[0].toString();
			cout << "\n";

			//now the mutating!-------------------------------------------
			roundNum = 0;
			while(stagnantRounds < STAGNANT_RANDOM_ROUNDS_LIMIT){

				//msRoundStartTime = clock(); //time(NULL);

				//replace the lower half with mutants!
				for (int i = 0; i < RANDOM_SET_SIZE/2; i++){
					vRandomLayouts[i+RANDOM_SET_SIZE/2] = vRandomLayouts[i]; //make a duplicate
					vRandomLayouts[i].mutateLayout();						//mutate original
					vRandomLayouts[i].calculateScore();						//score mutant
				}

				//here we sort the vector and eliminate duplicates (by mutating them!)
				sortAndEliminateDuplicates(vRandomLayouts);

				//check for new best score / stagnant round
				if (vRandomLayouts[0].getScore() < lastRoundsBest){
					lastRoundsBest = vRandomLayouts[0].getScore();
					stagnantRounds = 0;
				}else{
					++stagnantRounds;
				}
				++roundNum;

				cout << "Pool " << poolNum << "'s Best Layout After Mutation Round " << roundNum 
					<< " (" << stagnantRounds << "/" << STAGNANT_RANDOM_ROUNDS_LIMIT << " stagnant)"
					<<":  " << "\n";
				cout << vRandomLayouts[0].toString();
				//cout << "(" << ((clock()-msRoundStartTime)/1000.0) << "s)";
				cout << "\n";

			}//while(stagnantPools<=STAGNANT_POOLS_LIMIT){	// mutate until stagnant

			//add the best 32 to the vAllStarLayouts
			for (int i = 0; i < 32; i++){//top 32
				vAllStarLayouts.push_back(Keyboard(vRandomLayouts[i]));
			}

			if (vRandomLayouts[0].getScore() < bestPoolYet){ //if there's a new 'best layout ever'
				bestPoolYet = vRandomLayouts[0].getScore();
				stagnantPools = 0;
				cout << '\a'; //beep
			}else{
				++stagnantPools;
			}

			++poolNum;
		}//while(stagnantPools<=STAGNANT_POOLS_LIMIT) // until the pools have stagnated

		//print out the allstars (program readable format)
		outfile.open(LAST_NEW_ALLSTARS_FILE);
		for (vector<Keyboard>::size_type i = 0; i < vAllStarLayouts.size(); i++){
			outfile << vAllStarLayouts[i].getName() << "\n" 
					<< vAllStarLayouts[i].getLayoutStr() << "\n";
		}
		outfile.close();

	}//if (EvoNew == EvolutionMethodChoice)
	else if (EvoContinue == EvolutionMethodChoice){

		//TODO:  read in the last set into the allstar vector

		Keyboard::setTestMethod(testMethodAllStar);
		
		string name;
		string layout;

		infile.open(LAST_NEW_ALLSTARS_FILE);
		while(getline(infile, name)){
			if ('\r' == name[name.size()-1]) name.erase(name.size()-1);
			if (!name.empty()){
				getline(infile, layout);
				if ('\r' == layout[layout.size()-1]) layout.erase(layout.size()-1);
				vAllStarLayouts.push_back(Keyboard(name,layout));
		}	}
		infile.close();
		infile.clear();

		cout << vAllStarLayouts.size() << " layouts recovered\n\n";

/*		infile.open(LAST_NEW_ALLSTARS_FILE);
		while(getline(infile, name)){
			if ('\r' == name[name.size()-1]) name.erase(name.size()-1);
			if (!name.empty()){
				getline(infile, layout);
				if ('\r' == layout[layout.size()-1]) layout.erase(layout.size()-1);
				vAllStarLayouts.push_back(Keyboard(name,layout));
		}	}
		infile.close();*/

	}//else if (EvoContinue == EvolutionMethodChoice)

	//-----------------------------------------------------------------------------
	//all star round!
	//-----------------------------------------------------------------------------

	//get the appropriate test data
	Keyboard::setTestMethod(testMethodAllStar);
	if (testMethodAllStar == Keyboard::TEST_METHOD_TEXT){
		Keyboard::setTextToTest(getTextToTest(TEST_DATA_TEXT_FILE));
	}else if (testMethodAllStar == Keyboard::TEST_METHOD_COMBOS){
		Keyboard::setCombosToTest(
			getCombosToTest(TEST_DATA_COMBOS_FILE));
	}

	//since the test method may have changed, recalc the scores
	for (unsigned int i = 0; i < vAllStarLayouts.size(); i++){
		vAllStarLayouts[i].calculateScore();
	}

	sortAndEliminateDuplicates(vAllStarLayouts);

	//resize the allstar list
	if ((int)vAllStarLayouts.size() > MAX_ALLSTAR_SET_SIZE){
		vAllStarLayouts.resize(MAX_ALLSTAR_SET_SIZE);
	}

	cout << "\n" << "All-Star's Best Starting Layout:  " << "\n";
	cout << vAllStarLayouts[0].toString();
	cout << "\n";

	//now the allstar mutating!-------------------------------------------

	lastRoundsBest = vAllStarLayouts[0].getScore();
	stagnantRounds = 0;
	roundNum = 0;

	while(stagnantRounds < STAGNANT_ALLSTAR_ROUNDS_LIMIT){

		//replace the lower half with mutants!
		for (unsigned int i = 0; i < vAllStarLayouts.size()/2; i++){
			vAllStarLayouts[i + vAllStarLayouts.size()/2] = vAllStarLayouts[i];
			vAllStarLayouts[i + vAllStarLayouts.size()/2].mutateLayout();
			vAllStarLayouts[i + vAllStarLayouts.size()/2].calculateScore();
		}

		//here we sort the vector and eliminate duplicates (by mutating them!)
		sortAndEliminateDuplicates(vAllStarLayouts);
		
		//check for new best score / stagnant round
		if (vAllStarLayouts[0].getScore() < lastRoundsBest){
			lastRoundsBest = vAllStarLayouts[0].getScore();
			stagnantRounds=0;
		}else{
			++stagnantRounds;
		}
		++roundNum;

		cout << "\n" << "All-Star's Best Layout After Mutation Round " << roundNum  << ":  " << "\n";
		cout << vAllStarLayouts[0].toString();
		cout << "(" << stagnantRounds << "/" << STAGNANT_ALLSTAR_ROUNDS_LIMIT << " stagnant)";
		cout << "\n";

	}//mutate allstars until stagnant
	
	sAnalysisTotalTime = (time(NULL) - sAnalysisStartTime);
	std::stringstream summary;
	summary << Keyboard::getNumKeyboardsChecked() << " keyboards inspected (not all unique)) in " 
			<< std::setw(2) << std::setfill('0') << (sAnalysisTotalTime / 3600)
			<< ":" << std::setw(2) << (((long)sAnalysisTotalTime % 3600) / 60)
			<< ":" << std::setw(2) << (sAnalysisTotalTime % 60)
			<< " s (" << Keyboard::getNumKeyboardsChecked() / (long)sAnalysisTotalTime
			<< " kb/s)";

	cout << '\a'; //beep


	//print out the winners! (human readable format)
	outfile.open(string( 
		"z_allstars" + to_string<unsigned int>((unsigned int)time(NULL), std::dec) + ".txt" 
		).c_str());
	outfile << scoringParameters.scoringParameters() << "\n" << "\n";
	outfile << summary.str() << "\n" << "\n";
	for (int i = 0; i < 32; i++){//top 32
		outfile << vAllStarLayouts[i].toString() << "\n";
		outfile << vAllStarLayouts[i].scoreSummary() << "\n";
	}
	outfile.close();
	//print out the winners! (program readable format)
	/*outfile.open(LAST_ERA_ALLSTARS_FILE);
	for (vector<Keyboard>::size_type i = 0; i < vAllStarLayouts.size()/2; i++){
		outfile << vAllStarLayouts[i].getName() << "\n" 
			    << vAllStarLayouts[i].getLayoutStr() << "\n";
	}
	outfile.close();*/

	//-----------------------------------------------------------------------------
	//keep the window around (while guarding against accidentally hitting enter and not getting to look at it)
	cout << "Done!" << "\n"
		 << summary.str() << "\n" << "\n"
		 << "Any key and then Enter to exit (in case you want to test out the layout a bit here!)" << "\n";
	string dontclose;
	cin >> dontclose;
	return 0;

} ///:~

/*==============================================================================
sortAndEliminateDuplicates							  sortAndEliminateDuplicates
================================================================================
Sort the vector and remove duplicates by mutating them.
Loop until no dupes.
==============================================================================*/
void sortAndEliminateDuplicates(vector<Keyboard> &kbs){
	//here we sort the vector and eliminate duplicates (by mutating them!)
	//keep doing it until there are no dupes
	bool dupes;
	do{
		sort(kbs.begin(), kbs.end());

		dupes = false;
		for (unsigned int i = 0; i < kbs.size()-1; i++){
			if (kbs[i].equivalent(kbs[i+1])){
				dupes = true;
				kbs[i+1].mutateLayout();
				kbs[i+1].calculateScore();
			}
		}

	}while(dupes);
}

/*==============================================================================
getTextToTest											           getTextToTest
================================================================================
==============================================================================*/
static string getTextToTest(const char* filename){

	string textToTest;
	string line;
	std::ifstream in(filename);
	textToTest = "";
	while(getline(in, line)){
		if ('\r' == line[line.size()-1]) line.erase(line.size()-1);
		textToTest  += line + "\n";
	}
	in.close();
	return textToTest;
}

/*==============================================================================
getCombosToTest												     getCombosToTest
================================================================================
Assumes the file format is correct
==============================================================================*/
static vector<combo> getCombosToTest(const char* filename){

	vector<combo> combosToTest;
	combo tempCombo;
	string line;
	unsigned int lineAsUINT = 0;

	std::ifstream in(TEST_DATA_COMBOS_FILE, std::ios::in);

	while(getline(in, line)){
		if ('\r' == line[line.size()-1]) line.erase(line.size()-1);
		if (!line.empty()){
			tempCombo.chars = line;
			getline(in, line);
			if ('\r' == line[line.size()-1]) line.erase(line.size()-1);
			from_string<unsigned int>(lineAsUINT, line, std::dec);
			tempCombo.weight = lineAsUINT;
			combosToTest.push_back(tempCombo);
	}	}
	in.close();

	return combosToTest;
}
