import java.util.*;

/*****************************************************************
** MyUtil - miscellaneous static utility methods
**
**
** @author Scott MacKenzie, 2000
** @version 1.00
******************************************************************/
public class MyUtil
{
   /** Convert a string to a double.  This method provides a bit
   * more flexibility than <code>Double,parseDouble(String str)</code>
   * because it allows the passed string to be in base 2, 8, 10, or 16.<p>
   *
   * @param str the string to convert.
   * @param base the base of the number represented by the string.
   * Supported bases are 2, 8, 10, and 16.
   * @return a <code>double</code>, as represented by the string
   * argument.<p>
   *
   * The passed string represents a signed real number.  Examples:<p>
   *
   * <pre>
   *     convert("100.01", 2) returns 4.25
   *     convert("123.4", 8) returns 83.5
   *     convert("98.76", 10) returns 98.76
   *     convert("-e.f", 16) returns -14.9375
   * </pre>
   */
   public static double convert(String str, int base)
   {
      // if base 10, we're outta here
      if (base == 10)
         return Double.parseDouble(str);

      // if not base 10, we've got some work to do...

      double d = 0.0;
      int sign = 1;
      if (str.substring(0, 1).equals("-"))
      {
         sign = -1;
         str = str.substring(1);
      }
      int dp = str.indexOf(".") == -1 ? str.length() - 1 : str.indexOf(".") - 1;
      for (int i = 0; i < str.length(); ++i)
      {
         if (str.substring(i, i + 1).equals("."))
            continue;
         d += Math.pow(base, dp) * Integer.parseInt(str.substring(i, i + 1), base);
         --dp;              
      }
      d *= sign;
      return d;
   }

   /* Sort elements in an Object array.
   *
   * (Note: Implementation based on quick sort in Kernighan &
   * Ritchie, 2nd edition, p. 120)
   * @param d a Object array
   */
/* public static void sort(Object[] o)
   {
      qoSort(o, 0, o.length - 1);
   }

   private static void qoSort(Object[] n, int left, int right)
   {
      if (left >= right) // done when < 2 elements
         return;
      swap(n, left, (left + right) / 2);
      int last = left;
      for (int i = left + 1; i <= right; i++)
         if(n[i].compareTo(n[left]) < 0)
            swap(n, ++last, i);
      swap(n, left, last);
      qoSort(n, left, last - 1);
      qoSort(n, last + 1, right); 
   } */

   // swap elements 'i' and 'j' in array 'n'
   private static void swap(Object[] n, int i, int j)
   {
      Object temp = n[i];
      n[i] = n[j];
      n[j] = temp;
   }

   /** Sort elements in an double array.
   *
   * (Note: Implementation based on quick sort in Kernighan &
   * Ritchie, 2nd edition, p. 120)
   * @param d a double array
   */
   public static void sort(double[] d)
   {
      qdSort(d, 0, d.length - 1);
   }

   private static void qdSort(double[] n, int left, int right)
   {
      if (left >= right) // done when < 2 elements
         return;
      swap(n, left, (left + right) / 2);
      int last = left;
      for (int i = left + 1; i <= right; i++)
         if(n[i] < n[left])
            swap(n, ++last, i);
      swap(n, left, last);
      qdSort(n, left, last - 1);
      qdSort(n, last + 1, right); 
   }

   // swap elements 'i' and 'j' in array 'n'
   private static void swap(double[] n, int i, int j)
   {
      double temp = n[i];
      n[i] = n[j];
      n[j] = temp;
   }
      
   /** Sort elements in an integer array.
   *
   * (Note: Implementation based on quick sort in Kernighan &
   * Ritchie, 2nd edition, p. 120)
   * @param n an integer array
   */
   public static void sort(int[] n)
   {
      qiSort(n, 0, n.length - 1);
   }

   private static void qiSort(int[] n, int left, int right)
   {
      if (left >= right) // done when < 2 elements
         return;
      swap(n, left, (left + right) / 2);
      int last = left;
      for (int i = left + 1; i <= right; i++)
         if(n[i] < n[left])
            swap(n, ++last, i);
      swap(n, left, last);
      qiSort(n, left, last - 1);
      qiSort(n, last + 1, right); 
   }

   // swap elements 'i' and 'j' in array 'n'
   private static void swap(int[] n, int i, int j)
   {
      int temp = n[i];
      n[i] = n[j];
      n[j] = temp;
   }

   /**
   * Find the minimum value in a double array.
   * @param n a double array
   * @return the minimum value in the array
   */
   public static double min(double[] n)
   {
      double min = n[0];
      for (int j = 1; j < n.length; j++)
         if (n[j] < min)
            min = n[j];
      return min;
   }

   /**
   * Find the minimum value in an integer array.
   * @param n an integer array
   * @return the minimum value in the array
   */
   public static int min(int[] n)
   {
      int min = n[0];
      for (int j = 1; j < n.length; j++)
         if (n[j] < min)
            min = n[j];
      return min;
   }

   /** Find the minimum value in an array.
   * @param n a double array
   * @param length the length of the array (only the first 'length'
   * values will be searched.
   * @return the minimum value in the array.
   */
   public static double min(double[] n, int length)
   {
      double min = n[0];
      for (int j = 1; j < length; j++)
         if (n[j] < min)
            min = n[j];
      return min;
   }

   /** Find the maximum value in a double array.
   * @param n a double array
   * @param length the length of the array (only the first 'length'
   * values will be searched.
   * @return the maximum value in the array
   */
   public static double max(double[] n, int length)
   {
      double max = n[0];
      for (int j = 1; j < length; j++)
         if (n[j] > max)
            max = n[j];
      return max;
   }

   /** Find the maximum value in a double array.
   * @param n a double array
   * @return the maximum value in the array
   */
   public static double max(double[] n)
   {
      double max = n[0];
      for (int j = 1; j < n.length; j++)
         if (n[j] > max)
            max = n[j];
      return max;
   }

   /** Find the maximum value in an integer array.
   * @param n an integer array
   * @return the maximum value in the array
   */
   public static int max(int[] n)
   {
      int max = n[0];
      for (int j = 1; j < n.length; j++)
         if (n[j] > max)
            max = n[j];
      return max;
   }

   /** Calculate the mean of the values in an array.
   * @param n a double array
   * @param length the length of the array (only the first 'length'
   * values in the array are processed
   * @return the mean of the values in the array
   */
   public static double mean(double n[], int length)
   {
      double mean = 0.0;
      for (int j = 0; j < length; j++)
         mean += n[j];   
      return mean / length;
   }

   /** Calculate the mean of the values in a double array.
   * @param n a double array
   * @return a double equal to the mean of the values in the array.
   */
   public static double mean(double n[])
   {
      double mean = 0.0;
      for (int j = 0; j < n.length; j++)
         mean += n[j];   
      return mean / n.length;
   }

   /** Calculate the mean of the values in an integer array.
   * @param n an integer array
   * @return a double equal to the mean of the values in the array.
   */
   public static double mean(int n[])
   {
      double mean = 0.0;
      for (int j = 0; j < n.length; j++)
         mean += n[j];   
      return mean / n.length;
   }

   /** Calculate the mean of the values in an long array.
   * @param n an integer array
   * @return a double equal to the mean of the values in the array.
   */
   public static double mean(long n[])
   {
      double mean = 0.0;
      for (int j = 0; j < n.length; j++)
         mean += n[j];   
      return mean / n.length;
   }

   /** Calculate the standard deviation of values in an array.
   * @param n a double array
   * @param length the length of the array (only the first 'length'
   * values in the array are processed).
   * @return a double equal to the standard deviation of the
   * values in the array.
   */
   public static double sd(double[] n, int length)
   {
      double m = mean(n, length);
      double t = 0.0;
      for (int j = 0; j < length; j++)
         t += (m - n[j]) * (m - n[j]);
      return Math.sqrt(t / (length - 1.0));
   }

   /** Calculate the standard deviation of values in a double array.
   * @param n a double array
   * @return a double equal to the standard deviation of the
   * values in the array.
   */
   public static double sd(double[] n)
   {
      double m = mean(n);
      double t = 0.0;
      for (int j = 0; j < n.length; j++)
         t += (m - n[j]) * (m - n[j]);
      return Math.sqrt(t / (n.length - 1.0));
   }

   /** Calculate the standard deviation of values in an integer array.
   * @param n an integer array
   * @return a double equal to the standard deviation of the
   * values in the array.
   */
   public static double sd(int[] n)
   {
      double m = mean(n);
      double t = 0.0;
      for (int j = 0; j < n.length; j++)
         t += (m - n[j]) * (m - n[j]);
      return Math.sqrt(t / (n.length - 1.0));
   }

   /** Perform formatting services for an integer.
   * Integer 'i' is formatted as a string with the specified length,
   * padding to the left with spaces.
   * @param i an integer to format
   * @param len the length of the string to return
   * @return the formatted string
   */
   public static String formatInt(int i, int len)
   {
      String s = "" + i;
      while (s.length() < len)
         s = " " + s;
      return s;
   }

   /** Perform formatting services for a double.
   * Double 'd' is formatted as a string of length 'len'
   * with 'dp' decimal places.
   * The returned string is padded left with spaces, as necessary.
   *
   * @param d the double to format
   * @param len the length of the string to return
   * @param dp the number of decimal places to include. See
   * <code>trim()</code> for details.
   * @return the formatted double
   */
   public static String formatDouble(double d, int len, int dp)
   {
      String fx = (dp <= 0) ? "" + Math.round(d) : "" + trim(d, dp);

      // wierd adjustment needed; e.g., d = .004 & dp = 3
      while(fx.substring(fx.indexOf(".") + 1).length() > dp)
         fx = fx.substring(0, fx.length() -1);

      while (fx.substring(fx.indexOf(".") + 1).length() < dp)
         fx = fx + "0";

      while (fx.length() < len)
         fx = " " + fx;
      return fx;
   }

   /** Trim a double to the specified number of decimal places.<p>
   *
   * The <code>Math.round()</code> method is used to round the double before
   * trimming.  For example, 1.23456789 trimmed to three decimal places
   * is returned as 1.235.<p>
   *
   * @param d the double to trim
   * @param dp the number of decimal places desired
   * @return a double with the specified number of decimal places
   */
   public static double trim(double d, int dp)
   {
      int factor = 1;
      for (int i = 0; i < dp; ++i)
         factor *= 10;
      return (double)(Math.round(d * factor)) / factor;
   }

   /** Calculate the median value in an array of doubles.
   *
   * The median is the 50th percentile of a distribution -- the point
   * below which half of the data fall. In any distribution there will
   * always be an equal number of cases above and below the median.
   * For an odd number of cases, the median is the middle score when
   * they are arranged by rank order.  For an even number of scores,
   * the median is the point halfway between the two central values
   * when the scores are arranged by rank order.
   *
   * @param d a double array on which to calculate the median. (Note:
   * the array does <u>not</u> need to be pre-sorted.)
   * @param length the length of the array (only the first 'length'
   * values in the array are processed)
   * @return a double equal to the median value in the array
   */
   public static double median(double[] d, int length)
   {
      double[] tmp = new double[length];
      for (int i = 0; i < length; ++i)
         tmp[i] = d[i];
      Arrays.sort(tmp);
      if (length % 2 == 1)
         return tmp[length / 2];
      else
      {
         int i = length / 2 - 1;
         return (tmp[i] + tmp[i + 1]) / 2.0;
      }
   }

   /** Calculate the median value in an array of doubles.
   *
   * See the two-arg version of this method for further details.<p>
   */
   public static double median(double[] d)
   {
      return median(d, d.length);
   }

   /** Calculate the correlation between two sets of values.
   *
   * This method computes the Pearson coefficient of correlation. It
   * is the statistical summary of the degree and direction of
   * relationship of association between two variables.
   *
   * @param d1 an array of doubles
   * @param d2 an array of doubles
   * @param length the length of each array (only 'length' values
   * will be processed)
   * @return a double equal to the Pearson correlation coefficient
   */
   public static double corr(double[] d1, double[] d2, int length)
   {
      double cov = covariance(d1, d2, length);
      double sd1 = sd(d1, length);
      double sd2 = sd(d2, length);
      return cov / (sd1 * sd2);
   }

   /** Calculate the correlation between two sets of values
   * (two-argument version).
   */
   public static double corr(double[] x, double[] y)
   {
      return corr(x, y, x.length);
   }  

   /** Caculate the covariance between two sets of values.
   *
   * The covariance is a measure of association in many problems
   * in physical sciences and engineering.  It is an adequate
   * measure as long as the scales (means and variances) of the
   * variables are not arbitrary.  But, most variables in social
   * and behavioural sciences are measured on an arbitrary
   * scale; hence, correlation coefficients are generally
   * preferred to covariance as measures of relationship.
   *
   * @param d1 an array of doubles
   * @param d2 an array of doubles
   * @param length the length of each array (only the first 'length'
   * values are processed
   * @return a double equal to the covariance between the two
   * sets of values
   */
   public static double covariance(double[] d1, double[] d2, int length)
   {
      double cov = 0.0;
      double m1 = mean(d1, length);
      double m2 = mean(d2, length);
      for (int i = 0; i < length; ++i)
               cov += (d1[i] - m1) * (d2[i] - m2);
      return cov /= (length - 1);
   }

   /** Self-test method for the MyUtil static methods.
   * Just 'execute' the MyUtil 'program' and observe the output
   */
   public static void main(String[] args)
   {
      System.out.println("*** Test the median() method ***");
      System.out.println("Even number of elements...");
      double[] d1 = { 40.0, 3.0, 2.0, 1.0 };
      System.out.print("Array: ");
      for (int i = 0; i < d1.length; ++i)
         System.out.print(d1[i] + "  ");
      System.out.println();
      System.out.println("Median: " + median(d1, d1.length));

      System.out.println("Odd number of elements...");
      double[] d2 = { 50.0, 4.0, 3.0, 2.0, 1.0 };
      System.out.print("Array: ");
      for (int i = 0; i < d2.length; ++i)
         System.out.print(d2[i] + "  ");
      System.out.println();
      System.out.println("Median: " + median(d2, d2.length));

      System.out.println("*** Test the corr() method ***");
      double[] a1 = { 580, 350, 380, 470, 480, 490, 500, 510, 510,
                      550, 570, 580, 590, 590, 600, 620, 630, 630,
                      710, 760 };
      double[] a2 = {  64,  43,  55,  73,  45,  64,  69,  69,  77,
                       65,  84,  76,  79,  80,  58,  68,  69,  75,
                       69,  78 };
      System.out.println("data...");
      for (int i = 0; i < a1.length; ++i)
         System.out.println(a1[i] + "    " + a2[i]);
      System.out.println("Correlation (should be .543): " +
         corr(a1, a2, a1.length));

      System.out.println("*** Test the sort() method (int) ***");
      int[] x = { 10, 5, 2, 0, -1, 999, -8 };
      System.out.print("Original array: ");
      for (int i = 0; i < x.length; ++i)
         System.out.print(x[i] + "  ");
      System.out.println();
      sort(x);
      System.out.print("Sorted array: ");
      for (int i = 0; i < x.length; ++i)
         System.out.print(x[i] + "  ");
      System.out.println();

      System.out.println("*** Test the sort() method (double) ***");
      double[] d = { 10.0, 5.99, 21.1, 0.1, -1.8, 999.9, -8.2 };
      System.out.print("Original array: ");
      for (int i = 0; i < d.length; ++i)
         System.out.print(d[i] + "  ");
      System.out.println();
      sort(d);
      System.out.print("Sorted array: ");
      for (int i = 0; i < d.length; ++i)
         System.out.print(d[i] + "  ");
      System.out.println();

      System.out.println("*** Test the slope() and intercept() methods ***");
      double[] x1 = { 20, 30, 40, 60, 70, 90, 100, 120, 150, 180 };
      double[] y1 = { 3.5, 7.4, 7.1, 15.6, 11.1, 14.9, 23.5, 27.1, 22.1, 32.9 };
      System.out.println("Original arrays: ");
      System.out.print("x: ");
      for (int i = 0; i < x1.length; ++i)
         System.out.print(x1[i] + " ");
      System.out.println();
      System.out.print("y: ");
      for (int i = 0; i < y1.length; ++i)
         System.out.print(y1[i] + " ");
      System.out.println();
      System.out.println("Regression line slope: " + slope(x1, y1));
      System.out.println("Regression line intercept: " + intercept(x1, y1));
      System.out.println("Regression line equation: y = " +
         formatDouble(intercept(x1, y1), 5, 2) + " + " +
         formatDouble(slope(x1, y1), 5, 2) + " * x");
      System.out.println("*** Text the significance() method ***");
      System.out.println("if r = .196 and n = 100, p < " +
         significance(.196, 100));

   }

   /** Determine if a string contains only letter (a-z, A-Z)
   *
   * @param s a string to analyse
   * @return true of the string contains only letters
   */
   public static boolean isWord(String s)
   {
      boolean result = true;
      for (int i = 0; i < s.length(); ++i)
      {
         char c = Character.toLowerCase(s.charAt(i));
         if (c < 'a' || c > 'z')
            result = false;
      }
      return result;
   }

   /** Compute the slope of a regression line.
   *
   * Regression line coefficients are computed using the least squares
   * method.  Typically, the <code>x</code> values are controlled (independent)
   * and the <code>y</code> values are measured (dependent).  In computing the regression
   * line, the <code>y</code> values are 'regressed on' the <code>x</code> values.  The regression
   * line equation predicts <code>y</code> as a linear function of <code>x</code>.
   *
   * @param x a double array
   * @param y a double array
   * @return a double representing the slope of the regression line
   */
   public static double slope(double[] x, double[] y)
   {
      double sx2 = 0.0;
      double sx = 0.0;
      double sxy = 0.0;
      double sy = 0.0;
      for (int i = 0; i < x.length; ++i)
      {
         sx2 += x[i] * x[i];
         sx += x[i];
         sxy += x[i] * y[i];
         sy += y[i];
      }

      double sxx = x.length * sx2 - sx * sx;
      sxy = x.length * sxy - sx * sy;

      return sxy / sxx; 
   }

   /** Compute the intercept of a regression line.
   *
   * Regression line coefficients are computed using the least squares
   * method.  Typically, the <code>x</code> values are controlled (independent)
   * and the <code>y</code> values are measured (dependent).  In computing the regression
   * line, the <code>y</code> values are 'regressed on' the <code>x</code> values.  The regression
   * line equation predicts <code>y</code> as a linear
   * function of <code>x</code>.<p>
   *
   * @param x a double array
   * @param y a double array
   * @return a double representing the slope of the regression intercept
   */
   public static double intercept(double[] x, double[] y)
   {
      return mean(y) - slope(x, y) * mean(x);
   }

   /** Find the significance of <i>r</i>, given <i>n</i>.<p>
   *
   * The significance is the <i>p</i>-value of the correlation statistic
   * (<i>r</i>) for two variables. 
   * The returned value represents the upper bound of the significance
   * of <i>r</i>.  The assumption is a two-tailed test with
   * H0: <i>p</i> = 0.  For example,
   * if <i>r</i> = .765 and <i>n</i> = 10, the returned value is
   * 0.01.  In other words, <i>p</i> < .01.<p>
   *
   * 
   * The significance is computed using a look-up table.  Entries were
   * obtained from Table J in Glass, G. V., & Hopkins, K. D.
   * <i>Statistical methods in education and psychology</i> (2nd ed.),
   * Prentice Hall, 1984.<p>
   *
   * @param r the Pearson correlation
   * @param n the number of paired samples used to compute <i>r</i>
   * @return a double equal to the significane of the correlation.
   * If <i>n</i> > 1000, the returned value is 1.0.  If the computed
   * <i>p</i> is less than .05, the returned value is -1.0 (i.e., not
   * significant).
   */
   public static double significance(double r, int n)
   {
      final double[][] TABLE = {
        {    3.0, .997, .9995, .9999, .9994 },
        {    4.0, .950, .980,  .990,  .999  },
        {    5.0, .878, .934,  .959,  .991  },
        {    6.0, .881, .882,  .917,  .974  },
        {    7.0, .754, .833,  .874,  .951  },
        {    8.0, .707, .789,  .834,  .925  },
        {    9.0, .666, .750,  .798,  .898  },
        {   10.0, .632, .716,  .765,  .827  },
        {   11.0, .602, .685,  .735,  .847  },
        {   12.0, .576, .658,  .708,  .823  },
        {   13.0, .553, .658,  .708,  .823  },
        {   14.0, .532, .612,  .661,  .780  },
        {   15.0, .514, .592,  .641,  .760  },
        {   16.0, .497, .574,  .623,  .742  },
        {   17.0, .482, .558,  .602,  .725  },
        {   18.0, .468, .524,  .590,  .708  },
        {   19.0, .456, .528,  .575,  .693  },
        {   20.0, .444, .516,  .561,  .679  },
        {   25.0, .396, .462,  .505,  .618  },
        {   30.0, .361, .423,  .463,  .570  },
        {   35.0, .333, .391,  .428,  .531  },
        {   40.0, .312, .366,  .402,  .501  },
        {   50.0, .276, .328,  .361,  .451  },
        {  100.0, .196, .232,  .256,  .324  },
        {  200.0, .139, .164,  .182,  .232  },
        {  500.0, .088, .104,  .115,  .147  },
        { 1000.0, .062, .074,  .081,  .104  }
      };

      // if n is huge, probably highly significant, return 1
      if (n > 1000) return 1.0;

      // find the pertinent row in the table.
      int i = 0;
      while ((double)n > TABLE[i][0])
         ++i;

      // find the significant (upper bound) for r
      if (r >= TABLE[i][4]) return .001;
      if (r >= TABLE[i][3]) return  .05;
      if (r >= TABLE[i][2]) return  .01;
      if (r >= TABLE[i][1]) return  .05;

      return -1.0; // not significant
   }
}
