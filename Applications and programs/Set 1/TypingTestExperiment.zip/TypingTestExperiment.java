import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.io.*;
import java.util.*;

/**
 * TypingTestExperiment - experiment software to implement a simple typing test.
 * <p>
 * 
 * The program also provides a demonstration of the dependent measurements typically gathered in text entry experiments
 * (e.g., entry speed in words per minute, KSPC, and the MSD error rate).
 * <p>
 * 
 * Invocation:
 * <p>
 * 
 * <pre>
*     PROMPT>java TypingTestExperiment
* </pre>
 * 
 * Configuration parameters are read from <code><a href="TypingTestExperiment.cfg">TypingTestExperiment.cfg</a></code>
 * and appear in a setup dialog when the program is launched:
 * <p>
 * 
 * <center><img src = "TypingTestExperiment-1.jpg"></center>
 * <p>
 * 
 * Among the program parameters is a phrases file containing text phrases which are randomly presented for input. The
 * default file is <a href="phrases2.txt">phrases2.txt</a>, as published in <a
 * href="http://www.yorku.ca/mack/chi03b.html">Phrase sets for evaluating text entry techniques</a> (MacKenzie &
 * Soukoreff, <i>CHI 2003</i>). Three other phrases files are selectable through through the popup chooser: <a
 * href="helloworld.txt">helloworld.txt</a>, <a href="quickbrownfox.txt">quickbrownfox.txt</a>, and <a
 * href="phrases.txt">phrases.txt</a>. The latter file contains 1004 phrases with an average length of 41 characters
 * (compared to 500 phrases with an average length of 29 characters for phrases2.txt).
 * <p>
 * 
 * When the main program window opens, a phrase of text appears in the presented text field. As the user types, text
 * appears in the transcribed text field. Timing begins with the first keystroke. At the end of each phrase, the user
 * presses the ENTER key. This terminates entry of the current phrase, displays the summary statistics, and brings up
 * the next phrase to be entered.
 * <p>
 * 
 * Here's a screen snap of the program in action...
 * <p>
 * 
 * <center><img src = "TypingTestExperiment-2.jpg"></center>
 * <p>
 * 
 * At the end of a block, two output data files are created, an "sd1" file and an "sd2" file. ("sd" is for
 * "summary data".) The sd1 file contains the presented and transcribed text and the sampled keystrokes with timestamps
 * for each phrase entered. The sd2 file contains summary data, one line per phrase.
 * <p>
 * 
 * Here are example output data files:
 * <p>
 * 
 * <ul>
 * <li><a href="TypingTestExperiment-sd1example.txt">sd1 example</a>
 * <li><a href="TypingTestExperiment-sd2example.txt">sd2 example</a>
 * </ul>
 * 
 * The output data files use "TypingTestExperiment" as the base filename. This is followed by the participant code,
 * device code, and block code, for example, <code>TypingTestExperiment-P01-D01-B01.sd1</code>. The values for
 * the participant, device, and block codes is estblished via the setup dialog (see above).
 * <p>
 * 
 * When using this program in an experiment, it is a good idea to terminate all other applications and disable the
 * system's network connection. This will maintain the integrity of the data collected and ensure that the program runs
 * without hesitations.
 * <p>
 * 
 * @see <a href="TypingTestExperiment.java">source code</a>
 * @author Scott MacKenzie, 2001-2013
 */
public class TypingTestExperiment
{
	public static void main(String[] args) throws IOException
	{
		// use Win32 look and feel
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e)
		{
		}

		// read *default* condiguration data from file
		TypingTestExperimentConfiguration c = readConfigurationData();

		// use setup to allow changes to default configuration
		TypingTestExperimentSetup s = new TypingTestExperimentSetup(null, c);
		s.showTypingTestExperimentSetup(null);

		TypingTestExperimentGui screen = new TypingTestExperimentGui(c);
		screen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		screen.setTitle("Typing Test Experiment");
		screen.pack();

		// put application in centre of screen
		int w = screen.getWidth();
		int h = screen.getHeight();
		Toolkit t = Toolkit.getDefaultToolkit();
		Dimension d = t.getScreenSize();
		screen.setLocation((d.width - w) / 2, (d.height - h) / 2);

		screen.setVisible(true);
	}

	private static TypingTestExperimentConfiguration readConfigurationData() throws IOException
	{
		BufferedReader br = null;
		String fileName = "TypingTestExperiment.cfg";
		String line = "";

		try
		{
			br = new BufferedReader(new FileReader(fileName));
		} catch (FileNotFoundException e)
		{
			System.out.println("Configuration file not found: " + fileName);
			System.exit(1);
		}

		// read line (repeat until data line read)

		// PARTICIPANT CODE (used in name of output data files)
		while ((line = br.readLine().trim()).length() == 0 || line.charAt(0) == '#')
			continue;
		String participantCode = line;

		// DEVICE CODE (used in name of output data files)
		while ((line = br.readLine().trim()).length() == 0 || line.charAt(0) == '#')
			continue;
		String deviceCode = line;

		// BLOCK CODE (used in name of output data files)
		while ((line = br.readLine().trim()).length() == 0 || line.charAt(0) == '#')
			continue;
		String blockCode = line;

		// NUMBER OF PHRASES
		while ((line = br.readLine().trim()).length() == 0 || line.charAt(0) == '#')
			continue;
		int numberOfPhrases = Integer.parseInt(line);

		// GET NAMES OF PHRASES FILES
		Vector<String> v = new Vector<String>();
		while ((line = br.readLine().trim()).length() == 0 || line.charAt(0) == '#')
			continue;
		do
		{
			v.addElement(line);
		} while (!(line = br.readLine().trim()).equals("."));
		String[] phrasesFile = new String[v.size()];
		v.copyInto(phrasesFile);

		// SHOW PRESENTED TEXT DURING INPUT
		while ((line = br.readLine().trim()).length() == 0 || line.charAt(0) == '#')
			continue;
		boolean showPresented = line.equals("yes") ? true : false;

		// --- finished reading configuration variables ---

		TypingTestExperimentConfiguration c = new TypingTestExperimentConfiguration(participantCode, deviceCode,
				blockCode, numberOfPhrases, phrasesFile, showPresented);
		return c;
	}
}

class TypingTestExperimentGui extends JFrame implements KeyListener
{
	// the following avoids a "warning" with Java 1.5.0 complier (?)
	static final long serialVersionUID = 42L;

	private BufferedWriter sd1File;
	private BufferedWriter sd2File;
	private Vector<Sample> samples;
	private String phrasesFile;
	private boolean showPresented;
	private boolean newPhrase = true;
	private Random r = new Random();
	private JTextField text1;
	private JTextField text2;
	private JTextArea results;
	private String[] phrases;
	private String pPhrase; // presented phrase
	// private String tPhrase; // transcribed phrase
	private long t1, t2;
	private int count; // count keystrokes per phrase
	private int phraseCount;
	private String conditionCode;

	private Font BIG = new Font("monospaced", Font.BOLD, 24);
	private Color BACKGROUND = new Color(254, 254, 218);
	private Color FOREGROUND = new Color(11, 11, 109);

	TypingTestExperimentConfiguration c;

	// constructor
	TypingTestExperimentGui(TypingTestExperimentConfiguration cArg) throws IOException
	{
		c = cArg;
		phraseCount = c.getNumberOfPhrases();
		phrasesFile = c.getPhrasesFile();
		showPresented = c.getShowPresented();

		String outputFile = "TypingTestExperiment-" + c.getParticipantCode() + "-" + c.getDeviceCode() + "-"
				+ c.getBlockCode();
		
		conditionCode = "TypingTestExperiment," + c.getParticipantCode() + "," + c.getDeviceCode() + ","
				+ c.getBlockCode() + ",";
		String sd2Header = conditionCode + "Keystrokes,Characters,Time,MSD,WPM,ER,KSPC\n";

		// initialize phrases
		File f = new File(phrasesFile);
		if (!f.exists())
		{
			System.out.println("\nPhrases file not found - " + phrasesFile);
			System.exit(1);
		}

		// open disk file for input
		BufferedReader inFile = new BufferedReader(new FileReader(phrasesFile));
		Vector<String> v = new Vector<String>();
		String s;
		while ((s = inFile.readLine()) != null)
			v.addElement(s);
		phrases = new String[v.size()];
		v.copyInto(phrases);

		// initialize output files
		String s1 = outputFile + ".sd1";
		String s2 = outputFile + ".sd2";
		JLabel warning = new JLabel("Output data files exist. Overwrite?");
		warning.setFont(new Font("sansserif", Font.PLAIN, 16));
		final Object[] OPTIONS = { "No", "Yes" };
		if ((new File(s1)).exists() || (new File(s2)).exists())
		{
			if (JOptionPane.showOptionDialog(this, warning, "Caution", JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, OPTIONS, OPTIONS[0]) == 0)
			{
				System.exit(1);
			}
		}
		sd1File = new BufferedWriter(new FileWriter(s1));
		sd2File = new BufferedWriter(new FileWriter(s2));

		// output header line to sd2 file
		try
		{
			sd2File.write(sd2Header, 0, sd2Header.length());
			sd2File.flush();
		} catch (IOException e)
		{
			System.err.println("ERROR WRITING HEADER LINE TO SD2 FILE!\n" + e);
			System.exit(1);
		}

		// initialize components
		text1 = new JTextField(50);
		text1.setFocusable(false);
		text1.setFont(BIG);
		text1.setBackground(new Color(254, 254, 218));
		text1.setForeground(new Color(11, 11, 109));
		JPanel text1Panel = new JPanel();
		text1Panel.add(text1);
		text1Panel.setBorder(new TitledBorder(new EtchedBorder(), "Presented text"));

		text2 = new JTextField(50);
		text2.setFont(BIG);
		text2.setBackground(BACKGROUND);
		text2.setForeground(FOREGROUND);
		JPanel text2Panel = new JPanel();
		text2Panel.add(text2);
		text2Panel.setBorder(new TitledBorder(new EtchedBorder(), "Transcribed text"));

		text2.setEditable(true);
		text2.addKeyListener(this);

		results = new JTextArea(13, 50);
		results.setFocusable(false);
		results.setFont(new Font("monospaced", Font.BOLD, 18));
		results.setBackground(BACKGROUND);
		results.setForeground(FOREGROUND);
		JPanel resultsPanel = new JPanel(new BorderLayout());
		resultsPanel.add(results, "Center");
		Border b1 = new EtchedBorder();
		Border b2 = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		resultsPanel.setBorder(new CompoundBorder(b1, b2));

		// present first phrase for input
		pPhrase = phrases[r.nextInt(phrases.length)];
		text1.setText(pPhrase);
		text2.setText("");
		results.setText("");
		t1 = 0;
		count = 0;
		samples = new Vector<Sample>();

		// layout components
		JPanel p1 = new JPanel();
		p1.setLayout(new BoxLayout(p1, BoxLayout.Y_AXIS));
		p1.add(Box.createRigidArea(new Dimension(5, 10)));
		p1.add(text1Panel);
		p1.add(Box.createRigidArea(new Dimension(5, 10)));
		p1.add(text2Panel);
		p1.add(Box.createRigidArea(new Dimension(5, 10)));

		JPanel p = new JPanel(new BorderLayout());
		p.add(p1, "North");
		p.add(resultsPanel, "South");

		this.setContentPane(p);
	}

	// Key listener interface methods
	public void keyReleased(KeyEvent ke)
	{
	}

	public void keyTyped(KeyEvent ke)
	{
	}

	public void keyPressed(KeyEvent ke)
	{
		if (newPhrase)
		{
			newPhrase = false;
			if (!showPresented)
				text1.setText("");
		}

		++count;
		if (t1 == 0)
			t1 = System.currentTimeMillis();
		String s = KeyEvent.getKeyText(ke.getKeyCode());
		t2 = System.currentTimeMillis() - t1;
		samples.addElement(new Sample(t2, s.toLowerCase()));
		if (s.equals("Enter"))
		{
			newPhrase = true;

			--count; // don't count pressing Enter as a keystroke

			results.setText(" DATA COLLECTED:");

			String s1 = pPhrase.toLowerCase();
			String s2 = text2.getText().toLowerCase();
			results.append("\n   Presented:   " + s1);
			results.append("\n   Transcribed: " + s2);

			// output number of keystrokes
			results.append("\n   Keystrokes:  " + count);
			String sd2Stuff = conditionCode;
			sd2Stuff += count + ", ";

			// output number of characters entered
			results.append("\n   Characters:  " + s2.length());
			sd2Stuff += s2.length() + ", ";

			// also give number of words (5 char/word)
			double d = MyUtil.trim(s2.length() / 5.0, 3);
			results.append(" (" + d + " words)");

			// output time in seconds
			d = MyUtil.trim(t2 / 1000.0, 2);
			results.append("\n   Time:        " + d + " s");
			sd2Stuff += d + ", ";

			// append output time in minutes
			d = MyUtil.trim(t2 / 1000.0 / 60.0, 3);
			results.append(" (" + d + " minutes)");

			// output minimum string distance

			MSD s1s2 = new MSD(s1, s2);
			int msd = s1s2.getMSD();
			results.append("\n   MSD:         " + msd);
			sd2Stuff += msd + ", ";

			// output separator
			// (below the line are the main dependent variables)
			results.append("\n");
			results.append("\n PARTICIPANT PERFORMANCE:");

			// output speed in words per minute
			d = MyUtil.trim(wpm(s2, t2), 2);
			results.append("\n   Entry Speed: " + d + " wpm");
			sd2Stuff += d + ", ";

			// output error rate (based on MSD statistic & alignments)
			d = s1s2.getErrorRateNew();
			d = MyUtil.trim(d, 2);
			results.append("\n   Error rate:  " + d + "%");
			sd2Stuff += d + ", ";

			// output KSPC (keystrokes per character)
			d = (double) count / s2.length();
			d = MyUtil.trim(d, 4);
			results.append("\n   KSPC:        " + d);
			sd2Stuff += d + "\n";

			// dump data
			String sd1Stuff = pPhrase + "\n" + s2 + "\n";
			for (int i = 0; i < samples.size(); ++i)
				sd1Stuff += samples.elementAt(i) + "\n";
			sd1Stuff += "#\n";

			try
			{
				sd1File.write(sd1Stuff, 0, sd1Stuff.length());
				sd1File.flush();
				sd2File.write(sd2Stuff, 0, sd2Stuff.length());
				sd2File.flush();
			} catch (IOException e)
			{
				System.err.println("ERROR WRITING TO DATA FILE!\n" + e);
				System.exit(1);
			}

			// terminate if finished last phrase in block
			if (--phraseCount == 0)
			{
				JLabel thankyou = new JLabel("End of block. Thank you.");
				thankyou.setFont(new Font("sansserif", Font.PLAIN, 16));
				JOptionPane.showMessageDialog(this, thankyou);
				try
				{
					sd1File.close();
					sd2File.close();
				} catch (IOException e)
				{
					System.err.println("ERROR CLOSING DATA FILES!\n" + e);
					System.exit(1);
				}
				System.exit(0);
			}

			// prepare for next phrase
			samples = new Vector<Sample>();
			pPhrase = phrases[r.nextInt(phrases.length)];
			text1.setText(pPhrase);
			text2.setText("");
			t1 = 0;
			count = 0;
		}
	}

	// compute typing speed in wpm given text entered and time in ms
	public static double wpm(String text, long msTime)
	{
		double speed = text.length();
		speed = speed / (msTime / 1000.0) * (60 / 5);
		return speed;
	}

	private class Sample
	{
		Sample(long l, String s)
		{
			time = l;
			key = s;
		}

		@Override
		public String toString()
		{
			return time + " " + key;
		}

		private long time;
		private String key;
	}
}

// ---------
// S E T U P
// ---------

class TypingTestExperimentSetup extends JDialog implements ActionListener, FocusListener, ItemListener
{
	// the following avoids a "warning" with Java 1.5.0 complier (?)
	static final long serialVersionUID = 42L;

	TypingTestExperimentConfiguration c, cSave;
	JLabel banner;
	JTextField participantCode;
	JComboBox<String> deviceCode;
	JComboBox<String> blockCode;
	JTextField numberOfPhrases;
	JComboBox<String> phrasesFile;
	JCheckBox showPresented;

	JButton okButton;
	JButton resetButton;
	JButton exitButton;

	String[] phrasesFileArray;

	final String[] DEVICE_CODES = { "D99", "D01", "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10" };

	final String[] BLOCK_CODES = { "B99", "B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B09", "B10", "B11", "B12",
			"B13", "B14", "B15", "B16", "B17", "B18", "B19", "B20", "B21", "B22", "B23", "B24", "B25", };

	final Font F16 = new Font("sansserif", Font.PLAIN, 16);

	TypingTestExperimentSetup(Frame owner, TypingTestExperimentConfiguration cArg)
	{
		super(owner, "Configure TypingTestExperiment", true);
		c = cArg;
		cSave = new TypingTestExperimentConfiguration(c.getParticipantCode(), c.getDeviceCode(), c.getBlockCode(),
				c.getNumberOfPhrases(), c.getPhrasesFileArray(), c.getShowPresented());

		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

		banner = new JLabel("Setup", SwingConstants.CENTER);
		banner.setFont(new Font("sansserif", Font.PLAIN, 24));
		banner.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

		participantCode = new JTextField();
		participantCode.setFont(F16);
		participantCode.addFocusListener(this);
		participantCode.addActionListener(this);

		deviceCode = new JComboBox<String>(DEVICE_CODES);
		deviceCode.setFont(F16);
		deviceCode.addFocusListener(this);
		deviceCode.addActionListener(this);

		blockCode = new JComboBox<String>(BLOCK_CODES);
		blockCode.setFont(F16);
		blockCode.addFocusListener(this);
		blockCode.addActionListener(this);

		numberOfPhrases = new JTextField();
		numberOfPhrases.setDocument(new IntegerDocument());
		numberOfPhrases.setFont(F16);
		numberOfPhrases.addFocusListener(this);
		numberOfPhrases.addActionListener(this);

		phrasesFileArray = c.getPhrasesFileArray();
		phrasesFile = new JComboBox<String>(phrasesFileArray);
		phrasesFile.setEditable(true);
		phrasesFile.setFont(F16);
		phrasesFile.addFocusListener(this);
		phrasesFile.addActionListener(this);

		showPresented = new JCheckBox();
		showPresented.setFont(F16);
		showPresented.setHorizontalAlignment(SwingConstants.RIGHT);
		showPresented.addItemListener(this);

		okButton = new JButton("OK");
		okButton.setFont(F16);
		okButton.addActionListener(this);

		resetButton = new JButton("Reset");
		resetButton.setFont(F16);
		resetButton.addActionListener(this);

		exitButton = new JButton("Exit");
		exitButton.setFont(F16);
		exitButton.addActionListener(this);

		okButton.setPreferredSize(resetButton.getPreferredSize());
		exitButton.setPreferredSize(resetButton.getPreferredSize());

		setDefaults();

		JPanel top = new JPanel();
		top.setLayout(new BorderLayout());

		JPanel labelPanel = new JPanel();
		labelPanel.setLayout(new GridLayout(0, 1, 0, 10));
		JLabel l1 = new JLabel("Participant code ", SwingConstants.RIGHT);
		l1.setFont(F16);
		labelPanel.add(l1);
		JLabel l2 = new JLabel("Device code ", SwingConstants.RIGHT);
		l2.setFont(F16);
		labelPanel.add(l2);
		JLabel l3 = new JLabel("Block code ", SwingConstants.RIGHT);
		l3.setFont(F16);
		labelPanel.add(l3);
		JLabel l4 = new JLabel("Number of phrases ", SwingConstants.RIGHT);
		l4.setFont(F16);
		labelPanel.add(l4);
		JLabel l5 = new JLabel("Phrases file ", SwingConstants.RIGHT);
		l5.setFont(F16);
		labelPanel.add(l5);
		labelPanel.add(showPresented);

		JPanel paramPanel = new JPanel();
		paramPanel.setLayout(new GridLayout(0, 1, 0, 10));
		paramPanel.add(participantCode);
		paramPanel.add(deviceCode);
		paramPanel.add(blockCode);
		paramPanel.add(numberOfPhrases);
		paramPanel.add(phrasesFile);
		JLabel l6 = new JLabel(" Show presented text during input", SwingConstants.LEFT);
		l6.setFont(F16);
		paramPanel.add(l6);

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BorderLayout());
		centerPanel.add(labelPanel, "West");
		centerPanel.add(paramPanel, "East");
		centerPanel.setBorder(new TitledBorder(new EtchedBorder(), "Parameters"));

		JPanel OKExitPanel = new JPanel();
		OKExitPanel.add(okButton);
		OKExitPanel.add(resetButton);
		OKExitPanel.add(exitButton);
		OKExitPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

		top.add("North", banner);
		top.add("Center", centerPanel);
		top.add("South", OKExitPanel);
		top.add("West", new JLabel("            "));
		top.add("East", new JLabel("            "));
		this.setContentPane(top);
		this.pack();
		okButton.requestFocus();
	}

	public void actionPerformed(ActionEvent ae)
	{
		Object source = ae.getSource();
		if (source == participantCode)
			c.setParticipantCode(participantCode.getText());
		else if (source == deviceCode)
			c.setDeviceCode(DEVICE_CODES[deviceCode.getSelectedIndex()]);
		else if (source == blockCode)
			c.setBlockCode(BLOCK_CODES[blockCode.getSelectedIndex()]);
		else if (source == numberOfPhrases)
			c.setNumberOfPhrases(Integer.parseInt(numberOfPhrases.getText()));
		else if (source == phrasesFile)
			c.setPhrasesFile((String) phrasesFile.getSelectedItem());
		else if (source == exitButton)
			System.exit(0);
		else if (source == resetButton)
			setDefaults();
		else if (source == okButton)
			this.setVisible(false);

		return;
	}

	public void focusGained(FocusEvent fe)
	{
	}

	public void focusLost(FocusEvent fe)
	{
		Object source = fe.getSource();
		if (source == participantCode)
			c.setParticipantCode(participantCode.getText());
		else if (source == deviceCode)
			c.setDeviceCode(DEVICE_CODES[deviceCode.getSelectedIndex()]);
		else if (source == blockCode)
			c.setBlockCode(BLOCK_CODES[blockCode.getSelectedIndex()]);
		else if (source == numberOfPhrases)
			c.setNumberOfPhrases(Integer.parseInt(numberOfPhrases.getText()));
		else if (source == phrasesFile)
			c.setPhrasesFile((String) phrasesFile.getSelectedItem());
	}

	// input validation class for numberOfPhrases text field
	class IntegerDocument extends PlainDocument
	{
		private static final long serialVersionUID = 1L;

		@Override
		public void insertString(int offset, String s, AttributeSet as) throws BadLocationException
		{
			if (s == null)
				return;

			// get the 'tentative' new content of the text field
			String tentative;
			int length = this.getLength();
			if (length == 0)
			{
				tentative = s;
			} else
			{
				String current = this.getText(0, length);
				StringBuffer sb = new StringBuffer(current);
				sb.insert(offset, s);
				tentative = sb.toString();
			}

			try
			{
				Integer.parseInt(tentative);
				super.insertString(offset, s, as);
			} catch (NumberFormatException nfe)
			{
			}
		}
	}

	public void itemStateChanged(ItemEvent ie)
	{
		Object source = ie.getSource();
		if (source == showPresented)
			c.setShowPresented(showPresented.isSelected());
	}

	private void setDefaults()
	{
		c.setParticipantCode(cSave.getParticipantCode());
		c.setDeviceCode(cSave.getDeviceCode());
		c.setBlockCode(cSave.getBlockCode());
		c.setNumberOfPhrases(cSave.getNumberOfPhrases());
		c.setPhrasesFile(cSave.getPhrasesFile());
		c.setShowPresented(cSave.getShowPresented());

		participantCode.setText(c.getParticipantCode());
		for (int i = 0; i < DEVICE_CODES.length; ++i)
		{
			if (c.getDeviceCode().equals(DEVICE_CODES[i]))
			{
				deviceCode.setSelectedIndex(i);
				break;
			}
		}
		for (int i = 0; i < BLOCK_CODES.length; ++i)
		{
			if (c.getBlockCode().equals(BLOCK_CODES[i]))
			{
				blockCode.setSelectedIndex(i);
				break;
			}
		}
		numberOfPhrases.setText("" + c.getNumberOfPhrases());
		// phrasesFile.setText(c.getPhrasesFile());
		showPresented.setSelected(c.getShowPresented());
	}

	public boolean showTypingTestExperimentSetup(Frame f)
	{
		this.setLocationRelativeTo(f);
		this.setVisible(true);
		return true;
	}
}

// -------------------------
// C O N F I G U R A T I O N
// -------------------------

class TypingTestExperimentConfiguration
{
	String participantCode, deviceCode, blockCode;
	String phrasesFile;
	String[] phrasesFileArray;
	int numberOfPhrases;
	boolean showPresented;

	TypingTestExperimentConfiguration(String participantCodeArg, String deviceCodeArg, String blockCodeArg,
			int numberOfPhrasesArg, String[] phrasesFileArrayArg, boolean showPresentedArg)
	{
		participantCode = participantCodeArg;
		deviceCode = deviceCodeArg;
		blockCode = blockCodeArg;
		numberOfPhrases = numberOfPhrasesArg;
		phrasesFileArray = phrasesFileArrayArg;
		phrasesFile = phrasesFileArray[0]; // default to 1st entry
		showPresented = showPresentedArg;
	}

	public void setParticipantCode(String participantCodeArg)
	{
		participantCode = participantCodeArg;
	}

	public void setDeviceCode(String deviceCodeArg)
	{
		deviceCode = deviceCodeArg;
	}

	public void setBlockCode(String blockCodeArg)
	{
		blockCode = blockCodeArg;
	}

	public void setNumberOfPhrases(int numberOfPhrasesArg)
	{
		numberOfPhrases = numberOfPhrasesArg;
	}

	public void setPhrasesFile(String phrasesFileArg)
	{
		phrasesFile = phrasesFileArg;
	}

	public void setPhrasesFileArray(String[] phrasesFileArrayArg)
	{
		phrasesFileArray = phrasesFileArrayArg;
	}

	public void setShowPresented(boolean showPresentedArg)
	{
		showPresented = showPresentedArg;
	}

	public String getParticipantCode()
	{
		return participantCode;
	}

	public String getDeviceCode()
	{
		return deviceCode;
	}

	public String getBlockCode()
	{
		return blockCode;
	}

	public int getNumberOfPhrases()
	{
		return numberOfPhrases;
	}

	public String getPhrasesFile()
	{
		return phrasesFile;
	}

	public String[] getPhrasesFileArray()
	{
		return phrasesFileArray;
	}

	public boolean getShowPresented()
	{
		return showPresented;
	}

	@Override
	public String toString()
	{
		return "TypingTestExperiment Configuration\n" + "=======================\n" + "Participant code = "
				+ participantCode + "\n" + "Device code = " + deviceCode + "\n" + "Block code = " + blockCode + "\n"
				+ "Number of phrases = " + numberOfPhrases + "\n" + "Phrases file = " + phrasesFileArray[0] + "\n"
				+ "Show presented = " + showPresented + "\n";
	}
}